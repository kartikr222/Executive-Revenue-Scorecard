#!/bin/sh
# Run from inside your cloned Executive-Revenue-Scorecard folder, with this pack's assets/ folder copied over it
git add assets/logo-circle.svg assets/logo-rectangle.svg
git commit -m "Brand: real circle and rectangle logos"
git push origin main
