# Executive Revenue Scorecard™
### by Kartik Clarity · Revenue Leak Detection · Think. Focus. Achieve.

A premium executive decision intelligence system built with Next.js 16, PostgreSQL, and Drizzle ORM.

## Overview

The Executive Revenue Scorecard™ answers the seven questions every revenue executive needs answered immediately:

1. **Where are we?** — Current MRR, ARR, plan attainment
2. **Are we improving or deteriorating?** — MoM growth, NRR trends
3. **Why?** — MRR waterfall: new, expansion, churn, contraction
4. **What is most dangerous?** — Risk panel with exposure quantification
5. **What is the biggest opportunity?** — Opportunity panel with weighted values
6. **What deserves management attention now?** — Executive State summary
7. **What should happen next?** — Specific, actionable recommendations

## Brand Colors

| Token | Hex | Usage |
|-------|-----|-------|
| Navy Primary | `#0F2460` | Headers, backgrounds, text |
| Navy Secondary | `#1B3A8C` | Borders, accents |
| Blue Active | `#2A56D0` | Interactive elements, charts |
| Light Blue | `#B8D9F8` | Badges, subtle accents |
| Background | `#F3F7FF` | Page background |

## Logos

Both logos are included as SVG files in `public/logos/`:
- `kartik-clarity-shield.svg` — Icon/symbol mark
- `kartik-clarity-wordmark.svg` — Full horizontal wordmark
- `kartik-clarity-shield-logo.svg` — Copy of shield
- `kartik-clarity-wordmark-logo.svg` — Copy of wordmark

## Quick Start

```bash
# 1. Install dependencies
npm install

# 2. Set up environment
cp .env.example .env
# Edit .env with your DATABASE_URL

# 3. Push schema
npx drizzle-kit push

# 4. Seed database (optional — see db/seed.sql)
psql $DATABASE_URL < db/seed.sql

# 5. Run development server
npm run dev
```

## Environment Variables

| Variable | Required | Description |
|----------|----------|-------------|
| `DATABASE_URL` | Yes | PostgreSQL connection string |

## Architecture

```
src/
├── app/
│   ├── api/
│   │   ├── dashboard/route.ts   # JSON API endpoint
│   │   └── health/route.ts      # Health check
│   ├── globals.css
│   ├── layout.tsx
│   └── page.tsx                 # Server component — fetches data
├── components/
│   ├── charts/                  # Recharts wrappers
│   ├── dashboard/               # Executive UI sections
│   └── ui/                      # Primitive components + logos
├── db/
│   ├── index.ts                 # Drizzle client
│   └── schema.ts                # Table definitions
└── lib/
    ├── format.ts                # Formatting utilities
    └── revenue-engine.ts        # All metric derivation logic
```

## Score Methodology

The Executive Revenue Score (0–100) is computed from 5 weighted dimensions:

| Dimension | Weight | Benchmark |
|-----------|--------|-----------|
| Revenue Performance | 30% | Plan attainment + MoM trend |
| Growth Trajectory | 25% | MoM growth vs 3% SaaS benchmark |
| Pipeline Health | 20% | Coverage ratio vs 3x minimum |
| Retention Strength | 15% | NRR vs 110% target |
| Forecast Confidence | 10% | Weighted pipeline vs monthly plan |

Every score is traceable. No fabricated numbers.

## Production Deployment

```bash
npm run build
npm run start
```

Health check available at `/api/health`.
