import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "Executive Revenue Scorecard™ | Kartik Clarity",
  description:
    "Kartik Clarity's Executive Revenue Scorecard™ — Revenue Leak Detection. Think. Focus. Achieve. Turn revenue data into executive decisions.",
  keywords: ["revenue scorecard", "executive dashboard", "revenue intelligence", "Kartik Clarity", "revenue leak detection"],
  authors: [{ name: "Kartik Clarity" }],
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <head>
        <meta name="viewport" content="width=device-width, initial-scale=1" />
      </head>
      <body className="bg-[#F3F7FF] text-slate-900 antialiased">{children}</body>
    </html>
  );
}
