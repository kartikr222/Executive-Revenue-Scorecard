import { db } from "@/db";
import {
  revenuePeriods,
  pipelineDeals,
  revenueRisks,
  revenueOpportunities,
  customerCohorts,
} from "@/db/schema";
import { asc, desc } from "drizzle-orm";
import { deriveMetrics } from "@/lib/revenue-engine";
import { DashboardClient } from "@/components/dashboard/DashboardClient";
import type {
  RevenuePeriod,
  PipelineDeal,
  RevenueRisk,
  RevenueOpportunity,
  CustomerCohort,
} from "@/lib/revenue-engine";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [rawPeriods, rawDeals, rawRisks, rawOpps, rawCohorts] = await Promise.all([
    db.select().from(revenuePeriods).orderBy(asc(revenuePeriods.period)),
    db.select().from(pipelineDeals).orderBy(desc(pipelineDeals.amount)),
    db.select().from(revenueRisks).orderBy(desc(revenueRisks.exposureAmount)),
    db.select().from(revenueOpportunities).orderBy(desc(revenueOpportunities.potentialAmount)),
    db.select().from(customerCohorts).orderBy(asc(customerCohorts.cohortPeriod)),
  ]);

  const periods: RevenuePeriod[] = rawPeriods.map((r) => ({
    period: r.period,
    mrr: parseFloat(r.mrr),
    newMrr: parseFloat(r.newMrr),
    expansionMrr: parseFloat(r.expansionMrr),
    churnedMrr: parseFloat(r.churnedMrr),
    contractionMrr: parseFloat(r.contractionMrr),
    plan: parseFloat(r.plan),
  }));

  const deals: PipelineDeal[] = rawDeals.map((d) => ({
    id: d.id,
    name: d.name,
    stage: d.stage,
    amount: parseFloat(d.amount),
    probability: d.probability,
    expectedCloseDate: d.expectedCloseDate,
    accountName: d.accountName,
    isAtRisk: d.isAtRisk,
    riskReason: d.riskReason,
  }));

  const risks: RevenueRisk[] = rawRisks.map((r) => ({
    id: r.id,
    title: r.title,
    description: r.description,
    exposureAmount: parseFloat(r.exposureAmount),
    severity: r.severity,
    category: r.category,
    recommendedAction: r.recommendedAction,
    isResolved: r.isResolved,
  }));

  const opps: RevenueOpportunity[] = rawOpps.map((o) => ({
    id: o.id,
    title: o.title,
    description: o.description,
    potentialAmount: parseFloat(o.potentialAmount),
    confidence: o.confidence,
    category: o.category,
    recommendedAction: o.recommendedAction,
    timeframe: o.timeframe,
  }));

  const cohorts: CustomerCohort[] = rawCohorts.map((c) => ({
    cohortPeriod: c.cohortPeriod,
    initialCount: c.initialCount,
    retainedCount: c.retainedCount,
    initialMrr: parseFloat(c.initialMrr),
    retainedMrr: parseFloat(c.retainedMrr),
    monthsElapsed: c.monthsElapsed,
  }));

  const metrics = deriveMetrics(periods, deals, risks, opps, cohorts);

  return (
    <DashboardClient
      metrics={metrics}
      deals={deals}
      risks={risks}
      opportunities={opps}
      cohorts={cohorts}
      asOf={new Date().toISOString()}
    />
  );
}
