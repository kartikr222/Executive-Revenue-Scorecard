/**
 * Revenue Engine – derives all metrics from source data.
 * All calculations are explicit and traceable.
 * No magic numbers. No fabricated scores.
 */

export interface RevenuePeriod {
  period: string;
  mrr: number;
  newMrr: number;
  expansionMrr: number;
  churnedMrr: number;
  contractionMrr: number;
  plan: number;
}

export interface PipelineDeal {
  id: number;
  name: string;
  stage: string;
  amount: number;
  probability: number;
  expectedCloseDate: string;
  accountName: string;
  isAtRisk: boolean;
  riskReason: string | null;
}

export interface RevenueRisk {
  id: number;
  title: string;
  description: string;
  exposureAmount: number;
  severity: string;
  category: string;
  recommendedAction: string;
  isResolved: boolean;
}

export interface RevenueOpportunity {
  id: number;
  title: string;
  description: string;
  potentialAmount: number;
  confidence: number;
  category: string;
  recommendedAction: string;
  timeframe: string;
}

export interface CustomerCohort {
  cohortPeriod: string;
  initialCount: number;
  retainedCount: number;
  initialMrr: number;
  retainedMrr: number;
  monthsElapsed: number;
}

export interface MrrWaterfall {
  period: string;
  opening: number;
  newMrr: number;
  expansionMrr: number;
  churnedMrr: number;
  contractionMrr: number;
  closing: number;
  plan: number;
  vsplan: number;
  momGrowth: number | null;
}

export interface ExecutiveScore {
  total: number; // 0-100
  dimensions: {
    revenuePerformance: { score: number; weight: number; rationale: string };
    growthTrajectory: { score: number; weight: number; rationale: string };
    pipelineHealth: { score: number; weight: number; rationale: string };
    retentionStrength: { score: number; weight: number; rationale: string };
    forecastConfidence: { score: number; weight: number; rationale: string };
  };
  interpretation: string;
  confidence: "high" | "medium" | "low";
}

export interface DerivedMetrics {
  currentMrr: number;
  currentArr: number;
  mrrGrowthMom: number;
  arrGrowthYoy: number | null;
  planAttainment: number;
  netRevenueRetention: number;
  grossRevenueRetention: number;
  netNewMrr: number;
  churnRate: number;
  expansionRate: number;
  pipelineCoverage: number;
  weightedPipeline: number;
  atRiskPipeline: number;
  totalRiskExposure: number;
  largestOpportunity: number;
  waterfalls: MrrWaterfall[];
  executiveScore: ExecutiveScore;
  executiveState: string;
  primaryRisk: string;
  primaryOpportunity: string;
  immediateAction: string;
}

function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

export function deriveMetrics(
  periods: RevenuePeriod[],
  deals: PipelineDeal[],
  risks: RevenueRisk[],
  opportunities: RevenueOpportunity[],
  cohorts: CustomerCohort[]
): DerivedMetrics {
  // Sort periods chronologically
  const sorted = [...periods].sort((a, b) => a.period.localeCompare(b.period));

  // Current and prior period
  const current = sorted[sorted.length - 1];
  const prior = sorted[sorted.length - 2];
  const yearAgo = sorted.length >= 13 ? sorted[sorted.length - 13] : null;

  const currentMrr = current.mrr;
  const currentArr = round2(currentMrr * 12);

  // MoM growth
  const mrrGrowthMom = prior ? round2(((currentMrr - prior.mrr) / prior.mrr) * 100) : 0;

  // YoY ARR growth
  const arrGrowthYoy = yearAgo
    ? round2(((currentMrr - yearAgo.mrr) / yearAgo.mrr) * 100)
    : null;

  // Plan attainment
  const planAttainment = round2((current.mrr / current.plan) * 100);

  // Net new MRR
  const netNewMrr = round2(
    current.newMrr + current.expansionMrr - current.churnedMrr - current.contractionMrr
  );

  // Churn rate = churned / prior MRR
  const churnRate = prior ? round2((current.churnedMrr / prior.mrr) * 100) : 0;

  // Expansion rate = expansion / prior MRR
  const expansionRate = prior ? round2((current.expansionMrr / prior.mrr) * 100) : 0;

  // NRR: (prior MRR + expansion - churn - contraction) / prior MRR
  const netRevenueRetention = prior
    ? round2(
        ((prior.mrr + current.expansionMrr - current.churnedMrr - current.contractionMrr) /
          prior.mrr) *
          100
      )
    : 100;

  // GRR: (prior MRR - churn - contraction) / prior MRR
  const grossRevenueRetention = prior
    ? round2(((prior.mrr - current.churnedMrr - current.contractionMrr) / prior.mrr) * 100)
    : 100;

  // Pipeline metrics – exclude closed won
  const openDeals = deals.filter((d) => d.stage !== "Closed-Won" && d.stage !== "Closed-Lost");
  const weightedPipeline = round2(
    openDeals.reduce((sum, d) => sum + (d.amount * d.probability) / 100, 0)
  );
  const totalPipeline = openDeals.reduce((sum, d) => sum + d.amount, 0);

  // Pipeline coverage vs quarterly target (3x rule)
  const quarterlyTarget = current.plan * 3;
  const pipelineCoverage = round2(totalPipeline / quarterlyTarget);

  // At-risk pipeline
  const atRiskPipeline = round2(
    openDeals
      .filter((d) => d.isAtRisk)
      .reduce((sum, d) => sum + d.amount, 0)
  );

  // Risk exposure
  const totalRiskExposure = round2(
    risks.filter((r) => !r.isResolved).reduce((sum, r) => sum + r.exposureAmount, 0)
  );

  // Largest opportunity
  const largestOpportunity = round2(
    opportunities.reduce((max, o) => Math.max(max, o.potentialAmount), 0)
  );

  // Waterfall calculation
  const waterfalls: MrrWaterfall[] = sorted.map((p, idx) => {
    const prev = idx > 0 ? sorted[idx - 1] : null;
    const opening = prev ? prev.mrr : p.mrr - p.newMrr - p.expansionMrr + p.churnedMrr + p.contractionMrr;
    const closing = p.mrr;
    const momGrowth = prev ? round2(((closing - prev.mrr) / prev.mrr) * 100) : null;
    return {
      period: p.period,
      opening,
      newMrr: p.newMrr,
      expansionMrr: p.expansionMrr,
      churnedMrr: -p.churnedMrr,
      contractionMrr: -p.contractionMrr,
      closing,
      plan: p.plan,
      vsplan: round2(((closing - p.plan) / p.plan) * 100),
      momGrowth,
    };
  });

  // ─── Executive Score ───
  // Each dimension is scored 0-100, then weighted.

  // 1. Revenue Performance (30%) – plan attainment + trend
  const rpBase = Math.min(100, planAttainment);
  const rpTrend = mrrGrowthMom > 3 ? 10 : mrrGrowthMom > 1 ? 5 : mrrGrowthMom > 0 ? 0 : -10;
  const revenuePerformanceScore = Math.max(0, Math.min(100, rpBase + rpTrend));

  // 2. Growth Trajectory (25%) – MoM growth vs benchmark (3% healthy SaaS MoM)
  const gtScore = Math.max(
    0,
    Math.min(100, 50 + (mrrGrowthMom - 3) * 10)
  );

  // 3. Pipeline Health (20%) – coverage ratio
  const phScore = Math.max(
    0,
    Math.min(100, (pipelineCoverage / 3) * 100)
  );

  // 4. Retention Strength (15%) – NRR benchmark: 110% is excellent
  const rsScore = Math.max(
    0,
    Math.min(100, ((netRevenueRetention - 80) / 40) * 100)
  );

  // 5. Forecast Confidence (10%) – weighted pipeline vs monthly target
  const fcRatio = weightedPipeline / current.plan;
  const fcScore = Math.max(0, Math.min(100, (fcRatio / 1.5) * 100));

  const total = round2(
    revenuePerformanceScore * 0.3 +
      gtScore * 0.25 +
      phScore * 0.2 +
      rsScore * 0.15 +
      fcScore * 0.1
  );

  const executiveScore: ExecutiveScore = {
    total,
    dimensions: {
      revenuePerformance: {
        score: round2(revenuePerformanceScore),
        weight: 30,
        rationale: `Plan attainment is ${planAttainment.toFixed(1)}%. MoM growth is ${mrrGrowthMom.toFixed(1)}%.`,
      },
      growthTrajectory: {
        score: round2(gtScore),
        weight: 25,
        rationale: `MoM growth of ${mrrGrowthMom.toFixed(1)}% vs 3% SaaS benchmark.`,
      },
      pipelineHealth: {
        score: round2(phScore),
        weight: 20,
        rationale: `Pipeline coverage is ${pipelineCoverage.toFixed(1)}x vs 3x minimum.`,
      },
      retentionStrength: {
        score: round2(rsScore),
        weight: 15,
        rationale: `NRR is ${netRevenueRetention.toFixed(1)}%. Target ≥110%.`,
      },
      forecastConfidence: {
        score: round2(fcScore),
        weight: 10,
        rationale: `Weighted pipeline is ${((fcRatio) * 100).toFixed(0)}% of monthly plan.`,
      },
    },
    interpretation:
      total >= 80
        ? "Revenue position is strong. Sustain growth initiatives and defend retention."
        : total >= 65
        ? "Revenue position is adequate. Identified risks require proactive management."
        : total >= 50
        ? "Revenue position has material weaknesses. Immediate leadership attention required."
        : "Revenue position is at risk. Executive intervention required across multiple dimensions.",
    confidence: sorted.length >= 6 ? "high" : sorted.length >= 3 ? "medium" : "low",
  };

  // Executive state summary
  const executiveState =
    planAttainment >= 100 && mrrGrowthMom >= 3
      ? "Revenue is above plan with positive momentum."
      : planAttainment >= 95
      ? "Revenue is near plan. Growth trajectory requires monitoring."
      : "Revenue is below plan. Management attention warranted.";

  // Primary risk (highest severity, unresolved)
  const sevOrder = { critical: 0, high: 1, medium: 2, low: 3 };
  const unresolvedRisks = risks
    .filter((r) => !r.isResolved)
    .sort((a, b) => (sevOrder[a.severity as keyof typeof sevOrder] ?? 9) - (sevOrder[b.severity as keyof typeof sevOrder] ?? 9));

  const primaryRisk = unresolvedRisks[0]?.title ?? "No critical risks identified.";

  // Primary opportunity (highest weighted potential)
  const sortedOpps = [...opportunities].sort(
    (a, b) => b.potentialAmount * b.confidence - a.potentialAmount * a.confidence
  );
  const primaryOpportunity = sortedOpps[0]?.title ?? "No opportunities identified.";

  // Immediate action
  const immediateAction =
    unresolvedRisks[0]?.recommendedAction ?? sortedOpps[0]?.recommendedAction ?? "No immediate action required.";

  return {
    currentMrr,
    currentArr,
    mrrGrowthMom,
    arrGrowthYoy,
    planAttainment,
    netRevenueRetention,
    grossRevenueRetention,
    netNewMrr,
    churnRate,
    expansionRate,
    pipelineCoverage,
    weightedPipeline,
    atRiskPipeline,
    totalRiskExposure,
    largestOpportunity,
    waterfalls,
    executiveScore,
    executiveState,
    primaryRisk,
    primaryOpportunity,
    immediateAction,
  };
}
