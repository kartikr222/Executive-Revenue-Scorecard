import {
  pgTable,
  serial,
  varchar,
  numeric,
  integer,
  timestamp,
  text,
  boolean,
} from "drizzle-orm/pg-core";

// Revenue periods – monthly actuals
export const revenuePeriods = pgTable("revenue_periods", {
  id: serial("id").primaryKey(),
  period: varchar("period", { length: 7 }).notNull().unique(), // "2024-01"
  mrr: numeric("mrr", { precision: 14, scale: 2 }).notNull(),
  newMrr: numeric("new_mrr", { precision: 14, scale: 2 }).notNull(),
  expansionMrr: numeric("expansion_mrr", { precision: 14, scale: 2 }).notNull(),
  churnedMrr: numeric("churned_mrr", { precision: 14, scale: 2 }).notNull(),
  contractionMrr: numeric("contraction_mrr", { precision: 14, scale: 2 }).notNull(),
  plan: numeric("plan", { precision: 14, scale: 2 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Pipeline deals
export const pipelineDeals = pgTable("pipeline_deals", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 200 }).notNull(),
  stage: varchar("stage", { length: 60 }).notNull(),
  amount: numeric("amount", { precision: 14, scale: 2 }).notNull(),
  probability: integer("probability").notNull(), // 0-100
  expectedCloseDate: varchar("expected_close_date", { length: 10 }).notNull(), // ISO date
  accountName: varchar("account_name", { length: 200 }).notNull(),
  isAtRisk: boolean("is_at_risk").default(false).notNull(),
  riskReason: text("risk_reason"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Revenue risks
export const revenueRisks = pgTable("revenue_risks", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull(),
  exposureAmount: numeric("exposure_amount", { precision: 14, scale: 2 }).notNull(),
  severity: varchar("severity", { length: 20 }).notNull(), // "critical" | "high" | "medium" | "low"
  category: varchar("category", { length: 60 }).notNull(),
  recommendedAction: text("recommended_action").notNull(),
  isResolved: boolean("is_resolved").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Opportunities
export const revenueOpportunities = pgTable("revenue_opportunities", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 200 }).notNull(),
  description: text("description").notNull(),
  potentialAmount: numeric("potential_amount", { precision: 14, scale: 2 }).notNull(),
  confidence: integer("confidence").notNull(), // 0-100
  category: varchar("category", { length: 60 }).notNull(),
  recommendedAction: text("recommended_action").notNull(),
  timeframe: varchar("timeframe", { length: 60 }).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

// Customer cohorts for retention
export const customerCohorts = pgTable("customer_cohorts", {
  id: serial("id").primaryKey(),
  cohortPeriod: varchar("cohort_period", { length: 7 }).notNull(), // "2024-01"
  initialCount: integer("initial_count").notNull(),
  retainedCount: integer("retained_count").notNull(),
  initialMrr: numeric("initial_mrr", { precision: 14, scale: 2 }).notNull(),
  retainedMrr: numeric("retained_mrr", { precision: 14, scale: 2 }).notNull(),
  monthsElapsed: integer("months_elapsed").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});
