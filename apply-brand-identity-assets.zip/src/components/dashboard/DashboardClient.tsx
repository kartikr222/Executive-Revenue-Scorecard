"use client";

import { useState } from "react";
import { clsx } from "clsx";
import { ExecutiveHeader } from "@/components/dashboard/ExecutiveHeader";
import { ExecutiveState } from "@/components/dashboard/ExecutiveState";
import { RiskPanel } from "@/components/dashboard/RiskPanel";
import { OpportunityPanel } from "@/components/dashboard/OpportunityPanel";
import { PipelineTable } from "@/components/dashboard/PipelineTable";
import { Scorecard } from "@/components/dashboard/Scorecard";
import { MrrTrendChart } from "@/components/charts/MrrTrendChart";
import { WaterfallChart } from "@/components/charts/WaterfallChart";
import { RetentionChart } from "@/components/charts/RetentionChart";
import { MetricCard } from "@/components/ui/MetricCard";
import { SectionHeader } from "@/components/ui/SectionHeader";
import { ShieldLogo, WordmarkLogo } from "@/components/ui/KartikLogo";
import { formatCurrency, formatPercent, formatPercentNeutral } from "@/lib/format";
import type { DerivedMetrics, PipelineDeal, RevenueRisk, RevenueOpportunity, CustomerCohort } from "@/lib/revenue-engine";

interface Props {
  metrics: DerivedMetrics;
  deals: PipelineDeal[];
  risks: RevenueRisk[];
  opportunities: RevenueOpportunity[];
  cohorts: CustomerCohort[];
  asOf: string;
}

type Tab = "overview" | "pipeline" | "retention" | "risks" | "opportunities" | "score";

const tabs: { id: Tab; label: string }[] = [
  { id: "overview",      label: "Overview" },
  { id: "pipeline",      label: "Pipeline" },
  { id: "retention",     label: "Retention" },
  { id: "risks",         label: "Risks" },
  { id: "opportunities", label: "Opportunities" },
  { id: "score",         label: "Score" },
];

export function DashboardClient({
  metrics,
  deals,
  risks,
  opportunities,
  cohorts,
  asOf,
}: Props) {
  const [activeTab, setActiveTab] = useState<Tab>("overview");

  const unresolvedRisks = risks.filter((r) => !r.isResolved);
  const criticalCount = unresolvedRisks.filter((r) => r.severity === "critical").length;

  const latestWaterfall = metrics.waterfalls[metrics.waterfalls.length - 1];

  return (
    <div className="min-h-screen bg-[#F3F7FF]">
      <ExecutiveHeader asOf={asOf} />

      {/* Tab nav */}
      <nav className="bg-white border-b border-[#1B3A8C]/10 sticky top-[60px] z-30">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-10">
          <div className="flex items-center gap-0 overflow-x-auto no-scrollbar">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                className={clsx(
                  "flex-shrink-0 px-5 py-4 text-[12px] font-semibold border-b-2 transition-colors relative",
                  activeTab === tab.id
                    ? "border-[#2A56D0] text-[#1B3A8C]"
                    : "border-transparent text-[#1B3A8C]/50 hover:text-[#1B3A8C] hover:border-[#2A56D0]/30"
                )}
                onClick={() => setActiveTab(tab.id)}
              >
                {tab.label}
                {tab.id === "risks" && criticalCount > 0 && (
                  <span className="ml-1.5 text-[9px] font-bold bg-red-500 text-white rounded-full w-4 h-4 inline-flex items-center justify-center">
                    {criticalCount}
                  </span>
                )}
              </button>
            ))}
          </div>
        </div>
      </nav>

      <main className="max-w-[1440px] mx-auto px-6 lg:px-10 py-8">
        {/* ─── OVERVIEW ─── */}
        {activeTab === "overview" && (
          <div className="space-y-8">
            {/* Executive State */}
            <ExecutiveState metrics={metrics} />

            {/* KPI Row */}
            <div>
              <SectionHeader
                title="Revenue Performance"
                description="Current period actuals vs plan. All values derived from source data."
              />
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <MetricCard
                  label="Monthly Recurring Revenue"
                  value={formatCurrency(metrics.currentMrr, true)}
                  sub={`ARR: ${formatCurrency(metrics.currentArr, true)}`}
                  trend={metrics.mrrGrowthMom >= 0 ? "up" : "down"}
                  trendLabel={`${formatPercent(metrics.mrrGrowthMom)} vs prior month`}
                  size="md"
                />
                <MetricCard
                  label="Net New MRR"
                  value={formatCurrency(metrics.netNewMrr, true)}
                  sub="New + Expansion − Churn − Contraction"
                  trend={metrics.netNewMrr >= 0 ? "up" : "down"}
                  trendLabel={metrics.netNewMrr >= 0 ? "Net positive" : "Net negative"}
                  size="md"
                />
                <MetricCard
                  label="Plan Attainment"
                  value={`${metrics.planAttainment.toFixed(1)}%`}
                  trend={metrics.planAttainment >= 100 ? "up" : "down"}
                  trendLabel={metrics.planAttainment >= 100 ? "Above plan" : `${(100 - metrics.planAttainment).toFixed(1)}pp gap`}
                  badge={metrics.planAttainment >= 100 ? "On Track" : "Below Plan"}
                  badgeVariant={metrics.planAttainment >= 100 ? "positive" : "high"}
                  size="md"
                />
                <MetricCard
                  label="Weighted Pipeline"
                  value={formatCurrency(metrics.weightedPipeline, true)}
                  sub={`Coverage: ${metrics.pipelineCoverage.toFixed(1)}x of quarterly target`}
                  trend={metrics.pipelineCoverage >= 3 ? "up" : "down"}
                  trendLabel={metrics.pipelineCoverage >= 3 ? "Sufficient" : "Below 3x minimum"}
                  size="md"
                />
              </div>
            </div>

            {/* MRR Trend + Waterfall */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              <div className="lg:col-span-2 bg-white border border-[#1B3A8C]/10 rounded-xl p-6">
                <SectionHeader
                  title="MRR Trend"
                  description="Monthly actuals vs plan over 12 periods. Dashed line = plan."
                />
                <MrrTrendChart waterfalls={metrics.waterfalls} />
              </div>

              <div className="bg-white border border-[#1B3A8C]/10 rounded-xl p-6">
                <SectionHeader
                  title="MRR Waterfall"
                  description="Current month components."
                />
                {latestWaterfall && <WaterfallChart waterfall={latestWaterfall} />}
                <div className="mt-3 grid grid-cols-2 gap-2">
                  <div className="text-center p-2 bg-emerald-50 rounded-lg border border-emerald-200">
                    <div className="text-[13px] font-bold text-emerald-700 tabular-nums">
                      +{formatCurrency(latestWaterfall?.newMrr ?? 0, true)}
                    </div>
                    <div className="text-[9px] text-emerald-600 uppercase tracking-wide">New MRR</div>
                  </div>
                  <div className="text-center p-2 bg-emerald-50 rounded-lg border border-emerald-200">
                    <div className="text-[13px] font-bold text-emerald-700 tabular-nums">
                      +{formatCurrency(latestWaterfall?.expansionMrr ?? 0, true)}
                    </div>
                    <div className="text-[9px] text-emerald-600 uppercase tracking-wide">Expansion</div>
                  </div>
                  <div className="text-center p-2 bg-red-50 rounded-lg border border-red-200">
                    <div className="text-[13px] font-bold text-red-600 tabular-nums">
                      {formatCurrency(latestWaterfall?.churnedMrr ?? 0, true)}
                    </div>
                    <div className="text-[9px] text-red-500 uppercase tracking-wide">Churn</div>
                  </div>
                  <div className="text-center p-2 bg-red-50 rounded-lg border border-red-200">
                    <div className="text-[13px] font-bold text-red-600 tabular-nums">
                      {formatCurrency(latestWaterfall?.contractionMrr ?? 0, true)}
                    </div>
                    <div className="text-[9px] text-red-500 uppercase tracking-wide">Contraction</div>
                  </div>
                </div>
              </div>
            </div>

            {/* Secondary metrics */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <MetricCard
                label="Net Revenue Retention"
                value={`${formatPercentNeutral(metrics.netRevenueRetention)}`}
                sub="Target ≥ 110%"
                trend={metrics.netRevenueRetention >= 110 ? "up" : metrics.netRevenueRetention >= 100 ? "neutral" : "down"}
                trendLabel={metrics.netRevenueRetention >= 110 ? "Excellent" : metrics.netRevenueRetention >= 100 ? "Adequate" : "Below target"}
                badge={metrics.netRevenueRetention >= 110 ? "Excellent" : metrics.netRevenueRetention >= 100 ? "Adequate" : "At Risk"}
                badgeVariant={metrics.netRevenueRetention >= 110 ? "positive" : metrics.netRevenueRetention >= 100 ? "low" : "high"}
              />
              <MetricCard
                label="Gross Revenue Retention"
                value={`${formatPercentNeutral(metrics.grossRevenueRetention)}`}
                sub="Churn + Contraction impact"
                trend={metrics.grossRevenueRetention >= 90 ? "neutral" : "down"}
                trendLabel={metrics.grossRevenueRetention >= 90 ? "Healthy" : "Below benchmark"}
              />
              <MetricCard
                label="Monthly Churn Rate"
                value={`${formatPercentNeutral(metrics.churnRate)}`}
                sub="% of prior MRR churned"
                trend={metrics.churnRate <= 2 ? "up" : "down"}
                trendLabel={metrics.churnRate <= 2 ? "Below benchmark" : "Above benchmark"}
                badge={metrics.churnRate <= 2 ? "Healthy" : "Monitor"}
                badgeVariant={metrics.churnRate <= 2 ? "positive" : "high"}
              />
              <MetricCard
                label="At-Risk Pipeline"
                value={formatCurrency(metrics.atRiskPipeline, true)}
                sub="Deals flagged with active risk signals"
                trend="down"
                trendLabel="Requires attention"
                badge={metrics.atRiskPipeline > 0 ? "Flagged" : "Clean"}
                badgeVariant={metrics.atRiskPipeline > 0 ? "high" : "positive"}
              />
            </div>

            {/* Brand footer in overview */}
            <div className="bg-[#0F2460] rounded-2xl p-6 flex items-center justify-between gap-6 flex-wrap">
              <div className="flex items-center gap-4">
                <ShieldLogo size={52} />
                <div>
                  <div className="text-white font-bold text-lg">Kartik Clarity</div>
                  <div className="text-[#B8D9F8] text-[12px] mt-0.5">Revenue Leak Detection</div>
                  <div className="text-[#B8D9F8]/50 text-[10px] uppercase tracking-[0.12em] mt-1">
                    Think · Focus · Achieve
                  </div>
                </div>
              </div>
              <div className="max-w-md">
                <p className="text-[#B8D9F8]/80 text-[13px] leading-relaxed">
                  The Executive Revenue Scorecard™ turns your revenue data into executive decisions.
                  Every metric is calculated transparently from source data — no fabricated scores,
                  no opaque AI insights.
                </p>
              </div>
              <div className="text-right">
                <div className="text-[#B8D9F8]/50 text-[10px] uppercase tracking-widest">Revenue Score</div>
                <div className="text-white font-bold text-3xl tabular-nums">
                  {Math.round(metrics.executiveScore.total)}
                  <span className="text-[#B8D9F8]/40 text-lg">/100</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ─── PIPELINE ─── */}
        {activeTab === "pipeline" && (
          <div>
            <SectionHeader
              title="Pipeline"
              description="All active and recently closed deals. Sort by amount, probability, or close date. At-risk deals are flagged with the active risk signal."
              badge={`${deals.filter((d) => d.stage !== "Closed-Won" && d.stage !== "Closed-Lost").length} open`}
            />
            <PipelineTable deals={deals} />
          </div>
        )}

        {/* ─── RETENTION ─── */}
        {activeTab === "retention" && (
          <div className="space-y-6">
            <SectionHeader
              title="Retention & Expansion"
              description="NRR measures revenue growth from existing customers. Target ≥110%. GRR measures gross retention before expansion. NRR above 100% means existing customers are growing — even without new logos."
            />

            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <MetricCard
                label="Net Revenue Retention"
                value={`${formatPercentNeutral(metrics.netRevenueRetention)}`}
                sub="Current month"
                trend={metrics.netRevenueRetention >= 110 ? "up" : "neutral"}
                trendLabel="vs 110% target"
                size="lg"
                badge={metrics.netRevenueRetention >= 110 ? "Excellent" : "Adequate"}
                badgeVariant={metrics.netRevenueRetention >= 110 ? "positive" : "low"}
              />
              <MetricCard
                label="Gross Revenue Retention"
                value={`${formatPercentNeutral(metrics.grossRevenueRetention)}`}
                sub="Excluding expansion"
                trend="neutral"
                trendLabel="Pre-expansion"
                size="lg"
              />
              <MetricCard
                label="Expansion Rate"
                value={`${formatPercentNeutral(metrics.expansionRate)}`}
                sub="% of prior MRR expanded"
                trend={metrics.expansionRate >= 3 ? "up" : "neutral"}
                trendLabel={metrics.expansionRate >= 3 ? "Healthy expansion" : "Expansion opportunity"}
                size="lg"
              />
              <MetricCard
                label="Monthly Churn Rate"
                value={`${formatPercentNeutral(metrics.churnRate)}`}
                sub="% of prior MRR lost"
                trend={metrics.churnRate <= 2 ? "up" : "down"}
                trendLabel={metrics.churnRate <= 2 ? "Within benchmark" : "Accelerating"}
                badge={metrics.churnRate <= 2 ? "Healthy" : "Monitor"}
                badgeVariant={metrics.churnRate <= 2 ? "positive" : "high"}
                size="lg"
              />
            </div>

            <div className="bg-white border border-[#1B3A8C]/10 rounded-xl p-6">
              <SectionHeader
                title="Cohort NRR & GRR by Month"
                description="NRR (navy) and GRR (light blue) per cohort. Red dashed = 100% threshold. Green dashed = 110% excellence target."
              />
              <RetentionChart cohorts={cohorts} />
              <div className="mt-4 flex items-center gap-6 flex-wrap">
                <div className="flex items-center gap-2">
                  <div className="w-4 h-2 rounded bg-[#2A56D0]" />
                  <span className="text-[11px] text-slate-500">NRR (Net Revenue Retention)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-2 rounded bg-[#B8D9F8]" />
                  <span className="text-[11px] text-slate-500">GRR (Gross Revenue Retention)</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-0 border-t-2 border-dashed border-red-400" />
                  <span className="text-[11px] text-slate-500">100% threshold</span>
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-4 h-0 border-t-2 border-dashed border-emerald-400" />
                  <span className="text-[11px] text-slate-500">110% excellence target</span>
                </div>
              </div>
            </div>

            {/* Cohort table */}
            <div className="bg-white border border-[#1B3A8C]/10 rounded-xl overflow-hidden">
              <div className="px-6 py-4 border-b border-[#1B3A8C]/10">
                <h3 className="text-[11px] font-bold uppercase tracking-[0.08em] text-[#1B3A8C]/60">
                  Cohort Detail
                </h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full text-[12px]">
                  <thead>
                    <tr className="border-b border-[#1B3A8C]/10 bg-[#0F2460]/[0.03]">
                      <th className="px-5 py-3 text-left text-[10px] font-bold uppercase tracking-wider text-[#1B3A8C]/60">Cohort</th>
                      <th className="px-5 py-3 text-right text-[10px] font-bold uppercase tracking-wider text-[#1B3A8C]/60">Customers</th>
                      <th className="px-5 py-3 text-right text-[10px] font-bold uppercase tracking-wider text-[#1B3A8C]/60">Retained</th>
                      <th className="px-5 py-3 text-right text-[10px] font-bold uppercase tracking-wider text-[#1B3A8C]/60">Initial MRR</th>
                      <th className="px-5 py-3 text-right text-[10px] font-bold uppercase tracking-wider text-[#1B3A8C]/60">Current MRR</th>
                      <th className="px-5 py-3 text-right text-[10px] font-bold uppercase tracking-wider text-[#1B3A8C]/60">NRR</th>
                      <th className="px-5 py-3 text-right text-[10px] font-bold uppercase tracking-wider text-[#1B3A8C]/60">GRR</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-[#1B3A8C]/[0.06]">
                    {cohorts.map((c) => {
                      const nrr = (c.retainedMrr / c.initialMrr) * 100;
                      const grr = (c.retainedCount / c.initialCount) * 100;
                      return (
                        <tr key={c.cohortPeriod} className="hover:bg-[#B8D9F8]/10 transition-colors">
                          <td className="px-5 py-3 font-semibold text-[#0F2460]">{c.cohortPeriod}</td>
                          <td className="px-5 py-3 text-right text-slate-600">{c.initialCount}</td>
                          <td className="px-5 py-3 text-right text-slate-600">{c.retainedCount}</td>
                          <td className="px-5 py-3 text-right tabular-nums text-slate-600">{formatCurrency(c.initialMrr, true)}</td>
                          <td className="px-5 py-3 text-right tabular-nums font-semibold text-[#0F2460]">{formatCurrency(c.retainedMrr, true)}</td>
                          <td className="px-5 py-3 text-right tabular-nums">
                            <span className={nrr >= 110 ? "text-emerald-600 font-bold" : nrr >= 100 ? "text-[#2A56D0]" : "text-red-600"}>
                              {nrr.toFixed(1)}%
                            </span>
                          </td>
                          <td className="px-5 py-3 text-right tabular-nums text-slate-600">{grr.toFixed(1)}%</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}

        {/* ─── RISKS ─── */}
        {activeTab === "risks" && (
          <div>
            <SectionHeader
              title="Revenue Risks"
              description="Active risks ranked by exposure. Each risk includes evidence, exposure quantification, and a specific recommended action."
              badge={criticalCount > 0 ? `${criticalCount} Critical` : undefined}
              badgeVariant="critical"
            />
            <RiskPanel risks={risks} />
          </div>
        )}

        {/* ─── OPPORTUNITIES ─── */}
        {activeTab === "opportunities" && (
          <div>
            <SectionHeader
              title="Revenue Opportunities"
              description="Identified opportunities ranked by weighted value (potential × confidence). Each opportunity includes a recommended next action."
            />
            <OpportunityPanel opportunities={opportunities} />
          </div>
        )}

        {/* ─── SCORE ─── */}
        {activeTab === "score" && (
          <div className="max-w-2xl">
            <SectionHeader
              title="Executive Revenue Score™"
              description="A transparent, weighted composite score across 5 revenue dimensions. Every score is traceable to a specific metric and calculation."
            />
            <Scorecard score={metrics.executiveScore} />
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-[#1B3A8C]/10 bg-white mt-12 py-6">
        <div className="max-w-[1440px] mx-auto px-6 lg:px-10 flex items-center justify-between gap-4 flex-wrap">
          <div className="flex items-center gap-3">
            <ShieldLogo size={28} />
            <div>
              <div className="text-[12px] font-bold text-[#1B3A8C]">Kartik Clarity</div>
              <div className="text-[10px] text-[#1B3A8C]/50">Executive Revenue Scorecard™</div>
            </div>
          </div>
          <WordmarkLogo height={30} />
          <div className="text-[11px] text-[#1B3A8C]/40">
            Think. Focus. Achieve. · Revenue Leak Detection
          </div>
        </div>
      </footer>
    </div>
  );
}
