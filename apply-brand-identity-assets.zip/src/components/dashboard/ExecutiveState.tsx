"use client";

import { clsx } from "clsx";
import { formatCurrency, formatPercent, formatPercentNeutral } from "@/lib/format";
import type { DerivedMetrics } from "@/lib/revenue-engine";

interface Props {
  metrics: DerivedMetrics;
}

export function ExecutiveState({ metrics }: Props) {
  const score = metrics.executiveScore;
  const scoreColor =
    score.total >= 80
      ? "text-emerald-400"
      : score.total >= 65
      ? "text-[#B8D9F8]"
      : score.total >= 50
      ? "text-amber-400"
      : "text-red-400";

  const scoreBorder =
    score.total >= 80
      ? "border-emerald-400/30 bg-emerald-400/5"
      : score.total >= 65
      ? "border-[#2A56D0]/50 bg-[#2A56D0]/10"
      : score.total >= 50
      ? "border-amber-400/30 bg-amber-400/5"
      : "border-red-400/30 bg-red-400/5";

  const planColor =
    metrics.planAttainment >= 100 ? "text-emerald-400" : metrics.planAttainment >= 95 ? "text-amber-400" : "text-red-400";

  const mrrColor =
    metrics.mrrGrowthMom >= 3 ? "text-emerald-400" : metrics.mrrGrowthMom >= 1 ? "text-[#B8D9F8]" : "text-red-400";

  return (
    <div className="bg-[#0F2460] border border-[#2A56D0]/30 rounded-2xl overflow-hidden">
      {/* Top row — state statement */}
      <div className="px-6 py-5 border-b border-[#2A56D0]/20">
        <div className="flex items-start justify-between gap-4 flex-wrap">
          <div>
            <div className="text-[10px] font-bold uppercase tracking-[0.12em] text-[#B8D9F8]/50 mb-2">
              Executive State · January 2025
            </div>
            <p className="text-white text-[15px] font-medium leading-relaxed max-w-2xl">
              {metrics.executiveState}
            </p>
          </div>
          {/* Score badge */}
          <div className={clsx("border rounded-xl px-5 py-3 text-center flex-shrink-0", scoreBorder)}>
            <div className={clsx("text-4xl font-bold tabular-nums leading-none", scoreColor)}>
              {Math.round(score.total)}
            </div>
            <div className="text-[9px] font-bold uppercase tracking-[0.15em] text-[#B8D9F8]/60 mt-1">
              Revenue Score
            </div>
          </div>
        </div>
      </div>

      {/* 4-quadrant state bar */}
      <div className="grid grid-cols-2 lg:grid-cols-4 divide-x divide-[#2A56D0]/20">
        <StateCell
          label="Current MRR"
          value={formatCurrency(metrics.currentMrr, true)}
          sub={`ARR ${formatCurrency(metrics.currentArr, true)}`}
          trend={metrics.mrrGrowthMom >= 0 ? "up" : "down"}
          trendLabel={`${formatPercent(metrics.mrrGrowthMom)} MoM`}
          trendColor={mrrColor}
        />
        <StateCell
          label="Plan Attainment"
          value={`${metrics.planAttainment.toFixed(1)}%`}
          sub="vs monthly plan"
          trend={metrics.planAttainment >= 100 ? "up" : "down"}
          trendLabel={metrics.planAttainment >= 100 ? "Above plan" : "Below plan"}
          trendColor={planColor}
        />
        <StateCell
          label="Net Revenue Retention"
          value={`${formatPercentNeutral(metrics.netRevenueRetention)}`}
          sub={`GRR ${formatPercentNeutral(metrics.grossRevenueRetention)}`}
          trend={metrics.netRevenueRetention >= 110 ? "up" : metrics.netRevenueRetention >= 100 ? "neutral" : "down"}
          trendLabel={metrics.netRevenueRetention >= 110 ? "Excellent" : metrics.netRevenueRetention >= 100 ? "Adequate" : "Below target"}
          trendColor={metrics.netRevenueRetention >= 110 ? "text-emerald-400" : metrics.netRevenueRetention >= 100 ? "text-[#B8D9F8]" : "text-red-400"}
        />
        <StateCell
          label="Pipeline Coverage"
          value={`${metrics.pipelineCoverage.toFixed(1)}x`}
          sub="target: 3.0x minimum"
          trend={metrics.pipelineCoverage >= 3 ? "up" : "down"}
          trendLabel={metrics.pipelineCoverage >= 3 ? "Sufficient" : "Insufficient"}
          trendColor={metrics.pipelineCoverage >= 3 ? "text-emerald-400" : "text-red-400"}
        />
      </div>

      {/* Risk / Opportunity / Action bar */}
      <div className="grid grid-cols-1 md:grid-cols-3 divide-y md:divide-y-0 md:divide-x divide-[#2A56D0]/20 border-t border-[#2A56D0]/20">
        <AlertCell
          label="Primary Risk"
          value={metrics.primaryRisk}
          icon="⚠"
          color="text-red-400"
        />
        <AlertCell
          label="Largest Opportunity"
          value={metrics.primaryOpportunity}
          icon="◆"
          color="text-emerald-400"
        />
        <AlertCell
          label="Immediate Action"
          value={metrics.immediateAction}
          icon="→"
          color="text-[#B8D9F8]"
        />
      </div>
    </div>
  );
}

interface StateCellProps {
  label: string;
  value: string;
  sub: string;
  trend: "up" | "down" | "neutral";
  trendLabel: string;
  trendColor: string;
}

function StateCell({ label, value, sub, trend, trendLabel, trendColor }: StateCellProps) {
  const arrows = { up: "↑", down: "↓", neutral: "→" };
  return (
    <div className="px-5 py-4">
      <div className="text-[10px] font-semibold uppercase tracking-[0.08em] text-[#B8D9F8]/50 mb-2">
        {label}
      </div>
      <div className="text-white font-bold text-xl tabular-nums leading-none">{value}</div>
      <div className="mt-1.5 flex items-center gap-2 flex-wrap">
        <span className={clsx("text-[11px] font-semibold", trendColor)}>
          {arrows[trend]} {trendLabel}
        </span>
        <span className="text-[11px] text-[#B8D9F8]/45">{sub}</span>
      </div>
    </div>
  );
}

interface AlertCellProps {
  label: string;
  value: string;
  icon: string;
  color: string;
}

function AlertCell({ label, value, icon, color }: AlertCellProps) {
  return (
    <div className="px-5 py-4">
      <div className="flex items-center gap-2 mb-1.5">
        <span className={clsx("text-sm", color)}>{icon}</span>
        <span className="text-[10px] font-semibold uppercase tracking-[0.08em] text-[#B8D9F8]/50">
          {label}
        </span>
      </div>
      <p className="text-[12px] text-white/85 leading-relaxed line-clamp-2">{value}</p>
    </div>
  );
}
