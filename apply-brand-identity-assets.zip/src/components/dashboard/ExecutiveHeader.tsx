"use client";

import { ShieldLogo } from "@/components/ui/KartikLogo";

interface Props {
  asOf: string;
}

export function ExecutiveHeader({ asOf }: Props) {
  const date = new Date(asOf);
  const formatted = date.toLocaleDateString("en-US", {
    weekday: "long",
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return (
    <header className="sticky top-0 z-40 bg-[#0F2460] border-b border-[#2A56D0]/30">
      <div className="max-w-[1440px] mx-auto px-6 lg:px-10 h-[60px] flex items-center justify-between gap-4">
        {/* Logo */}
        <div className="flex items-center gap-3 min-w-0">
          <ShieldLogo size={36} />
          <div className="hidden sm:block min-w-0">
            <div className="flex items-center gap-2">
              <span className="text-white font-bold text-[15px] tracking-tight leading-none">Kartik Clarity</span>
              <span className="hidden md:inline-block text-[10px] font-semibold text-[#B8D9F8] uppercase tracking-[0.12em] bg-[#B8D9F8]/15 px-2 py-0.5 rounded">
                Revenue Leak Detection
              </span>
            </div>
            <div className="text-[10px] text-[#B8D9F8]/60 mt-0.5 tracking-[0.08em] uppercase">
              Think · Focus · Achieve
            </div>
          </div>
        </div>

        {/* Product title */}
        <div className="text-center hidden md:block">
          <h1 className="text-white font-semibold text-[13px] tracking-[0.04em]">
            Executive Revenue Scorecard™
          </h1>
          <p className="text-[10px] text-[#B8D9F8]/55 tracking-[0.05em] uppercase mt-0.5">
            Decision Intelligence System
          </p>
        </div>

        {/* Right: date + status */}
        <div className="text-right flex-shrink-0">
          <div className="text-[11px] text-[#B8D9F8]/60 uppercase tracking-[0.06em]">As of</div>
          <div className="text-[12px] font-medium text-white">{formatted}</div>
        </div>
      </div>
    </header>
  );
}
