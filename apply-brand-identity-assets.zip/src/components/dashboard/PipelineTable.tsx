"use client";

import { useState } from "react";
import { clsx } from "clsx";
import { formatCurrency, formatDate } from "@/lib/format";
import type { PipelineDeal } from "@/lib/revenue-engine";

interface Props {
  deals: PipelineDeal[];
}

const stageConfig: Record<string, { label: string; color: string; order: number }> = {
  "Discovery":    { label: "Discovery",    color: "bg-slate-100 text-slate-600 border-slate-200",        order: 1 },
  "Proposal":     { label: "Proposal",     color: "bg-[#B8D9F8]/40 text-[#1B3A8C] border-[#B8D9F8]",    order: 2 },
  "Negotiation":  { label: "Negotiation",  color: "bg-[#2A56D0]/10 text-[#1B3A8C] border-[#2A56D0]/30", order: 3 },
  "Closed-Won":   { label: "Closed Won",   color: "bg-emerald-100 text-emerald-700 border-emerald-200",  order: 4 },
  "Closed-Lost":  { label: "Closed Lost",  color: "bg-red-100 text-red-600 border-red-200",              order: 5 },
};

type SortKey = "amount" | "probability" | "expectedCloseDate";

export function PipelineTable({ deals }: Props) {
  const [sortKey, setSortKey] = useState<SortKey>("amount");
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc");
  const [stageFilter, setStageFilter] = useState<string>("all");

  const stages = Array.from(new Set(deals.map((d) => d.stage)));

  const filtered = deals.filter((d) => stageFilter === "all" || d.stage === stageFilter);

  const sorted = [...filtered].sort((a, b) => {
    let cmp = 0;
    if (sortKey === "amount") cmp = a.amount - b.amount;
    else if (sortKey === "probability") cmp = a.probability - b.probability;
    else if (sortKey === "expectedCloseDate")
      cmp = a.expectedCloseDate.localeCompare(b.expectedCloseDate);
    return sortDir === "asc" ? cmp : -cmp;
  });

  function toggleSort(key: SortKey) {
    if (sortKey === key) {
      setSortDir(sortDir === "asc" ? "desc" : "asc");
    } else {
      setSortKey(key);
      setSortDir("desc");
    }
  }

  const SortIcon = ({ k }: { k: SortKey }) => (
    <span className="ml-1 text-[10px] text-[#1B3A8C]/40">
      {sortKey === k ? (sortDir === "asc" ? "▲" : "▼") : "↕"}
    </span>
  );

  const openDeals = deals.filter((d) => d.stage !== "Closed-Won" && d.stage !== "Closed-Lost");
  const totalPipeline = openDeals.reduce((s, d) => s + d.amount, 0);
  const weightedPipeline = openDeals.reduce((s, d) => s + (d.amount * d.probability) / 100, 0);
  const atRiskCount = openDeals.filter((d) => d.isAtRisk).length;

  return (
    <div>
      {/* Pipeline summary */}
      <div className="grid grid-cols-3 gap-3 mb-5">
        <div className="bg-white border border-[#1B3A8C]/10 rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-[#0F2460] tabular-nums">
            {formatCurrency(totalPipeline, true)}
          </div>
          <div className="text-[10px] text-[#1B3A8C]/55 uppercase tracking-wider mt-1">Total Pipeline</div>
        </div>
        <div className="bg-white border border-[#1B3A8C]/10 rounded-xl p-4 text-center">
          <div className="text-2xl font-bold text-[#2A56D0] tabular-nums">
            {formatCurrency(weightedPipeline, true)}
          </div>
          <div className="text-[10px] text-[#1B3A8C]/55 uppercase tracking-wider mt-1">Weighted Pipeline</div>
        </div>
        <div className={clsx(
          "rounded-xl p-4 text-center border",
          atRiskCount > 0 ? "bg-red-50 border-red-200" : "bg-white border-[#1B3A8C]/10"
        )}>
          <div className={clsx("text-2xl font-bold tabular-nums", atRiskCount > 0 ? "text-red-600" : "text-[#0F2460]")}>
            {atRiskCount}
          </div>
          <div className="text-[10px] uppercase tracking-wider mt-1 text-slate-500">Deals At Risk</div>
        </div>
      </div>

      {/* Stage filter */}
      <div className="flex items-center gap-2 mb-4 flex-wrap">
        <button
          className={clsx(
            "text-[11px] font-semibold px-3 py-1.5 rounded-full border transition-colors",
            stageFilter === "all"
              ? "bg-[#1B3A8C] text-white border-[#1B3A8C]"
              : "bg-white text-[#1B3A8C] border-[#1B3A8C]/20 hover:border-[#2A56D0]"
          )}
          onClick={() => setStageFilter("all")}
        >
          All Stages
        </button>
        {stages.map((stage) => (
          <button
            key={stage}
            className={clsx(
              "text-[11px] font-semibold px-3 py-1.5 rounded-full border transition-colors",
              stageFilter === stage
                ? "bg-[#1B3A8C] text-white border-[#1B3A8C]"
                : "bg-white text-[#1B3A8C] border-[#1B3A8C]/20 hover:border-[#2A56D0]"
            )}
            onClick={() => setStageFilter(stage)}
          >
            {stageConfig[stage]?.label ?? stage}
          </button>
        ))}
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-xl border border-[#1B3A8C]/10">
        <table className="w-full text-[12px]">
          <thead>
            <tr className="border-b border-[#1B3A8C]/10 bg-[#0F2460]/[0.03]">
              <th className="px-4 py-3 text-left text-[10px] font-bold uppercase tracking-[0.07em] text-[#1B3A8C]/60">
                Deal / Account
              </th>
              <th className="px-4 py-3 text-left text-[10px] font-bold uppercase tracking-[0.07em] text-[#1B3A8C]/60">
                Stage
              </th>
              <th
                className="px-4 py-3 text-right text-[10px] font-bold uppercase tracking-[0.07em] text-[#1B3A8C]/60 cursor-pointer hover:text-[#1B3A8C] select-none"
                onClick={() => toggleSort("amount")}
              >
                Amount <SortIcon k="amount" />
              </th>
              <th
                className="px-4 py-3 text-right text-[10px] font-bold uppercase tracking-[0.07em] text-[#1B3A8C]/60 cursor-pointer hover:text-[#1B3A8C] select-none"
                onClick={() => toggleSort("probability")}
              >
                Prob. <SortIcon k="probability" />
              </th>
              <th className="px-4 py-3 text-right text-[10px] font-bold uppercase tracking-[0.07em] text-[#1B3A8C]/60">
                Weighted
              </th>
              <th
                className="px-4 py-3 text-right text-[10px] font-bold uppercase tracking-[0.07em] text-[#1B3A8C]/60 cursor-pointer hover:text-[#1B3A8C] select-none"
                onClick={() => toggleSort("expectedCloseDate")}
              >
                Close Date <SortIcon k="expectedCloseDate" />
              </th>
            </tr>
          </thead>
          <tbody className="divide-y divide-[#1B3A8C]/[0.06]">
            {sorted.map((deal) => {
              const stageCfg = stageConfig[deal.stage] ?? { label: deal.stage, color: "bg-slate-100 text-slate-600 border-slate-200" };
              const weighted = (deal.amount * deal.probability) / 100;

              return (
                <tr
                  key={deal.id}
                  className={clsx(
                    "hover:bg-[#B8D9F8]/10 transition-colors",
                    deal.isAtRisk && "bg-red-50/40"
                  )}
                >
                  <td className="px-4 py-3.5">
                    <div className="flex items-start gap-2">
                      {deal.isAtRisk && (
                        <span className="text-red-500 text-xs mt-0.5 flex-shrink-0" title={deal.riskReason ?? ""}>
                          ⚠
                        </span>
                      )}
                      <div>
                        <div className="font-semibold text-[#0F2460] leading-tight">{deal.name}</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">{deal.accountName}</div>
                        {deal.isAtRisk && deal.riskReason && (
                          <div className="text-[11px] text-red-600 mt-0.5 leading-tight">{deal.riskReason}</div>
                        )}
                      </div>
                    </div>
                  </td>
                  <td className="px-4 py-3.5">
                    <span className={clsx("text-[10px] font-semibold px-2 py-1 rounded-full border", stageCfg.color)}>
                      {stageCfg.label}
                    </span>
                  </td>
                  <td className="px-4 py-3.5 text-right font-semibold text-[#0F2460] tabular-nums">
                    {formatCurrency(deal.amount, true)}
                  </td>
                  <td className="px-4 py-3.5 text-right tabular-nums">
                    <div className="flex items-center justify-end gap-2">
                      <div className="w-16 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                        <div
                          className="h-full rounded-full bg-[#2A56D0]"
                          style={{ width: `${deal.probability}%` }}
                        />
                      </div>
                      <span className="text-slate-600 text-[11px]">{deal.probability}%</span>
                    </div>
                  </td>
                  <td className="px-4 py-3.5 text-right font-semibold text-[#2A56D0] tabular-nums">
                    {formatCurrency(weighted, true)}
                  </td>
                  <td className="px-4 py-3.5 text-right text-slate-600 text-[11px]">
                    {formatDate(deal.expectedCloseDate)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>

        {sorted.length === 0 && (
          <div className="text-center py-10 text-[#1B3A8C]/40 text-sm">
            No deals match the selected filter.
          </div>
        )}
      </div>
    </div>
  );
}
