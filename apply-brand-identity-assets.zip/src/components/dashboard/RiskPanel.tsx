"use client";

import { useState } from "react";
import { clsx } from "clsx";
import { formatCurrency } from "@/lib/format";
import type { RevenueRisk } from "@/lib/revenue-engine";

interface Props {
  risks: RevenueRisk[];
}

const severityConfig = {
  critical: {
    label: "Critical",
    bg: "bg-red-50 border-red-200",
    badge: "bg-red-100 text-red-700 border border-red-300",
    bar: "bg-red-500",
    dot: "bg-red-500",
    text: "text-red-700",
  },
  high: {
    label: "High",
    bg: "bg-orange-50 border-orange-200",
    badge: "bg-orange-100 text-orange-700 border border-orange-300",
    bar: "bg-orange-400",
    dot: "bg-orange-400",
    text: "text-orange-700",
  },
  medium: {
    label: "Medium",
    bg: "bg-amber-50 border-amber-200",
    badge: "bg-amber-100 text-amber-700 border border-amber-200",
    bar: "bg-amber-400",
    dot: "bg-amber-400",
    text: "text-amber-700",
  },
  low: {
    label: "Low",
    bg: "bg-[#B8D9F8]/20 border-[#B8D9F8]",
    badge: "bg-[#B8D9F8]/40 text-[#1B3A8C] border border-[#B8D9F8]",
    bar: "bg-[#2A56D0]",
    dot: "bg-[#2A56D0]",
    text: "text-[#1B3A8C]",
  },
};

export function RiskPanel({ risks }: Props) {
  const [expanded, setExpanded] = useState<number | null>(null);
  const active = risks.filter((r) => !r.isResolved);
  const totalExposure = active.reduce((sum, r) => sum + r.exposureAmount, 0);

  return (
    <div>
      {/* Summary bar */}
      <div className="mb-4 p-4 bg-red-50 border border-red-200 rounded-xl flex items-center justify-between gap-4 flex-wrap">
        <div>
          <div className="text-xs font-bold text-red-700 uppercase tracking-wider">Total Risk Exposure</div>
          <div className="text-2xl font-bold text-red-700 tabular-nums mt-0.5">
            {formatCurrency(totalExposure, true)}
          </div>
        </div>
        <div className="flex items-center gap-3 flex-wrap">
          {(["critical", "high", "medium"] as const).map((sev) => {
            const count = active.filter((r) => r.severity === sev).length;
            if (count === 0) return null;
            const cfg = severityConfig[sev];
            return (
              <span key={sev} className={clsx("text-[11px] font-bold px-2.5 py-1 rounded-full", cfg.badge)}>
                {count} {cfg.label}
              </span>
            );
          })}
        </div>
      </div>

      {/* Risk list */}
      <div className="space-y-3">
        {active.map((risk) => {
          const cfg = severityConfig[risk.severity as keyof typeof severityConfig] ?? severityConfig.low;
          const isOpen = expanded === risk.id;

          return (
            <div
              key={risk.id}
              className={clsx("border rounded-xl overflow-hidden transition-all", cfg.bg)}
            >
              {/* Header */}
              <button
                className="w-full px-5 py-4 flex items-start gap-3 text-left hover:bg-black/[0.02] transition-colors"
                onClick={() => setExpanded(isOpen ? null : risk.id)}
                aria-expanded={isOpen}
              >
                <span className={clsx("w-2 h-2 rounded-full mt-1.5 flex-shrink-0", cfg.dot)} />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="text-[13px] font-semibold text-slate-900">{risk.title}</span>
                    <span className={clsx("text-[10px] font-bold px-2 py-0.5 rounded-full", cfg.badge)}>
                      {cfg.label}
                    </span>
                    <span className="text-[10px] text-slate-500 bg-white/60 px-2 py-0.5 rounded-full border">
                      {risk.category}
                    </span>
                  </div>
                  <p className="text-[12px] text-slate-600 leading-relaxed line-clamp-2">
                    {risk.description}
                  </p>
                </div>
                <div className="flex-shrink-0 text-right ml-2">
                  <div className="text-[13px] font-bold text-slate-800 tabular-nums">
                    {formatCurrency(risk.exposureAmount, true)}
                  </div>
                  <div className="text-[10px] text-slate-500">exposure</div>
                </div>
                <span className="text-slate-400 text-sm ml-1 mt-0.5 flex-shrink-0">
                  {isOpen ? "▲" : "▼"}
                </span>
              </button>

              {/* Expanded detail */}
              {isOpen && (
                <div className="px-5 pb-5 pt-1 border-t border-black/[0.06]">
                  <div className="bg-white/60 rounded-lg p-4">
                    <div className="text-[10px] font-bold uppercase tracking-[0.08em] text-slate-500 mb-2">
                      Recommended Action
                    </div>
                    <p className="text-[13px] text-slate-800 leading-relaxed">{risk.recommendedAction}</p>
                    <div className="mt-3 flex items-center gap-2">
                      <div className="flex-1 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                        <div
                          className={clsx("h-full rounded-full", cfg.bar)}
                          style={{
                            width: `${Math.min(100, (risk.exposureAmount / totalExposure) * 100)}%`,
                          }}
                        />
                      </div>
                      <span className="text-[10px] text-slate-500 flex-shrink-0">
                        {((risk.exposureAmount / totalExposure) * 100).toFixed(0)}% of total exposure
                      </span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}

        {active.length === 0 && (
          <div className="text-center py-8 text-[#1B3A8C]/40 text-sm">
            No active revenue risks identified.
          </div>
        )}
      </div>
    </div>
  );
}
