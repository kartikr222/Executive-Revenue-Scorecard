"use client";

import { useState } from "react";
import { clsx } from "clsx";
import { formatCurrency } from "@/lib/format";
import type { RevenueOpportunity } from "@/lib/revenue-engine";

interface Props {
  opportunities: RevenueOpportunity[];
}

export function OpportunityPanel({ opportunities }: Props) {
  const [expanded, setExpanded] = useState<number | null>(null);

  const totalWeighted = opportunities.reduce(
    (sum, o) => sum + (o.potentialAmount * o.confidence) / 100,
    0
  );
  const totalPotential = opportunities.reduce((sum, o) => sum + o.potentialAmount, 0);

  return (
    <div>
      {/* Summary bar */}
      <div className="mb-4 p-4 bg-emerald-50 border border-emerald-200 rounded-xl flex items-center justify-between gap-4 flex-wrap">
        <div>
          <div className="text-xs font-bold text-emerald-700 uppercase tracking-wider">Weighted Opportunity Value</div>
          <div className="text-2xl font-bold text-emerald-700 tabular-nums mt-0.5">
            {formatCurrency(totalWeighted, true)}
          </div>
          <div className="text-[11px] text-emerald-600/70 mt-0.5">
            {formatCurrency(totalPotential, true)} total potential
          </div>
        </div>
        <div className="text-[12px] text-emerald-700 bg-emerald-100 border border-emerald-200 rounded-lg px-3 py-2 max-w-[200px]">
          {opportunities.length} identified opportunities across {new Set(opportunities.map((o) => o.category)).size} categories
        </div>
      </div>

      {/* Opportunity list */}
      <div className="space-y-3">
        {opportunities.map((opp) => {
          const weightedValue = (opp.potentialAmount * opp.confidence) / 100;
          const isOpen = expanded === opp.id;

          return (
            <div
              key={opp.id}
              className="border border-[#1B3A8C]/12 rounded-xl overflow-hidden bg-white"
            >
              <button
                className="w-full px-5 py-4 flex items-start gap-3 text-left hover:bg-[#B8D9F8]/10 transition-colors"
                onClick={() => setExpanded(isOpen ? null : opp.id)}
                aria-expanded={isOpen}
              >
                <span className="w-2 h-2 rounded-full mt-1.5 flex-shrink-0 bg-emerald-500" />
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2 flex-wrap mb-1">
                    <span className="text-[13px] font-semibold text-[#0F2460]">{opp.title}</span>
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full bg-[#B8D9F8]/40 text-[#1B3A8C] border border-[#B8D9F8]">
                      {opp.category}
                    </span>
                    <span className="text-[10px] text-slate-500 bg-slate-50 px-2 py-0.5 rounded-full border border-slate-200">
                      {opp.timeframe}
                    </span>
                  </div>
                  <p className="text-[12px] text-slate-600 leading-relaxed line-clamp-2">
                    {opp.description}
                  </p>
                </div>
                <div className="flex-shrink-0 text-right ml-2">
                  <div className="text-[13px] font-bold text-[#0F2460] tabular-nums">
                    {formatCurrency(weightedValue, true)}
                  </div>
                  <div className="text-[10px] text-slate-500">{opp.confidence}% confidence</div>
                </div>
                <span className="text-slate-400 text-sm ml-1 mt-0.5 flex-shrink-0">
                  {isOpen ? "▲" : "▼"}
                </span>
              </button>

              {/* Expanded */}
              {isOpen && (
                <div className="px-5 pb-5 pt-1 border-t border-[#1B3A8C]/8 bg-[#B8D9F8]/10">
                  <div className="bg-white rounded-lg p-4 border border-[#B8D9F8]/60">
                    <div className="grid grid-cols-3 gap-4 mb-4 text-center">
                      <div>
                        <div className="text-lg font-bold text-[#0F2460] tabular-nums">
                          {formatCurrency(opp.potentialAmount, true)}
                        </div>
                        <div className="text-[10px] text-slate-500 uppercase tracking-wide">Total Potential</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-emerald-600 tabular-nums">
                          {formatCurrency(weightedValue, true)}
                        </div>
                        <div className="text-[10px] text-slate-500 uppercase tracking-wide">Weighted Value</div>
                      </div>
                      <div>
                        <div className="text-lg font-bold text-[#2A56D0] tabular-nums">
                          {opp.confidence}%
                        </div>
                        <div className="text-[10px] text-slate-500 uppercase tracking-wide">Confidence</div>
                      </div>
                    </div>
                    <div className="text-[10px] font-bold uppercase tracking-[0.08em] text-slate-500 mb-2">
                      Recommended Action
                    </div>
                    <p className="text-[13px] text-slate-800 leading-relaxed">{opp.recommendedAction}</p>
                    <div className="mt-3 h-1.5 bg-slate-200 rounded-full overflow-hidden">
                      <div
                        className="h-full bg-emerald-500 rounded-full"
                        style={{ width: `${opp.confidence}%` }}
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
}
