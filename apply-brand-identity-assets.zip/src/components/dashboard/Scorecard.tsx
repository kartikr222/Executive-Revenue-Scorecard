"use client";

import { ScoreGauge } from "@/components/charts/ScoreGauge";
import type { ExecutiveScore } from "@/lib/revenue-engine";

interface Props {
  score: ExecutiveScore;
}

export function Scorecard({ score }: Props) {
  const dimensions = Object.entries(score.dimensions) as Array<
    [string, { score: number; weight: number; rationale: string }]
  >;

  const dimLabels: Record<string, string> = {
    revenuePerformance: "Revenue Performance",
    growthTrajectory: "Growth Trajectory",
    pipelineHealth: "Pipeline Health",
    retentionStrength: "Retention Strength",
    forecastConfidence: "Forecast Confidence",
  };

  return (
    <div className="bg-white border border-[#1B3A8C]/12 rounded-xl p-6">
      <div className="flex items-start gap-2 mb-5">
        <div>
          <h3 className="text-[11px] font-bold uppercase tracking-[0.08em] text-[#1B3A8C]/60">
            Executive Revenue Score™
          </h3>
          <p className="text-[12px] text-[#1B3A8C]/50 mt-0.5">
            5 weighted dimensions · Transparent methodology
          </p>
        </div>
      </div>

      <ScoreGauge score={score} />

      <div className="mt-5 pt-4 border-t border-[#1B3A8C]/10">
        <div className="text-[10px] font-bold uppercase tracking-[0.1em] text-[#1B3A8C]/50 mb-2">
          Interpretation
        </div>
        <p className="text-[13px] text-[#0F2460] leading-relaxed">{score.interpretation}</p>
      </div>

      {/* Dimension rationale */}
      <div className="mt-4 pt-4 border-t border-[#1B3A8C]/10 space-y-3">
        <div className="text-[10px] font-bold uppercase tracking-[0.1em] text-[#1B3A8C]/50 mb-1">
          Why this score?
        </div>
        {dimensions.map(([key, dim]) => (
          <div key={key} className="flex items-start gap-3">
            <div className="flex-shrink-0 w-8 h-8 rounded-lg bg-[#0F2460] flex items-center justify-center">
              <span className="text-[11px] font-bold text-white">{dim.weight}%</span>
            </div>
            <div className="min-w-0">
              <div className="text-[11px] font-semibold text-[#0F2460]">{dimLabels[key]}</div>
              <div className="text-[11px] text-slate-500 leading-relaxed">{dim.rationale}</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
