"use client";

import { clsx } from "clsx";

interface SectionHeaderProps {
  title: string;
  description?: string;
  className?: string;
  badge?: string;
  badgeVariant?: "critical" | "positive" | "warning" | "neutral";
}

export function SectionHeader({
  title,
  description,
  className,
  badge,
  badgeVariant = "neutral",
}: SectionHeaderProps) {
  const badgeColors = {
    critical: "bg-red-100 text-red-700 border border-red-200",
    positive: "bg-emerald-100 text-emerald-700 border border-emerald-200",
    warning: "bg-orange-100 text-orange-700 border border-orange-200",
    neutral: "bg-[#B8D9F8]/40 text-[#1B3A8C] border border-[#B8D9F8]",
  };

  return (
    <div className={clsx("mb-5", className)}>
      <div className="flex items-center gap-3">
        <h2 className="text-sm font-bold uppercase tracking-[0.07em] text-[#1B3A8C]">
          {title}
        </h2>
        {badge && (
          <span className={clsx("text-[10px] font-semibold px-2 py-0.5 rounded-full", badgeColors[badgeVariant])}>
            {badge}
          </span>
        )}
      </div>
      {description && (
        <p className="mt-1 text-[13px] text-[#1B3A8C]/60 leading-relaxed max-w-2xl">{description}</p>
      )}
    </div>
  );
}
