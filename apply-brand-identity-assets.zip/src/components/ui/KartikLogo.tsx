"use client";

interface ShieldLogoProps {
  size?: number;
  className?: string;
}

/**
 * Kartik Clarity shield logo – SVG inline for crisp rendering at all sizes.
 * Colors: brand navy #1B3A8C, brand blue #2A56D0, brand light blue #B8D9F8, white.
 */
export function ShieldLogo({ size = 40, className = "" }: ShieldLogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 200 200"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label="Kartik Clarity"
    >
      {/* Shield */}
      <path
        d="M100 14 L170 42 L170 110 C170 150 136 180 100 192 C64 180 30 150 30 110 L30 42 Z"
        fill="#1B3A8C"
        stroke="#2A56D0"
        strokeWidth="3"
      />
      <path
        d="M100 26 L158 50 L158 110 C158 144 128 170 100 180 C72 170 42 144 42 110 L42 50 Z"
        fill="#1E40AF"
      />

      {/* Bar charts left */}
      <rect x="56" y="84" width="10" height="26" rx="2.5" fill="#B8D9F8" opacity="0.9" />
      <rect x="70" y="72" width="10" height="38" rx="2.5" fill="#ADD8E6" opacity="0.95" />

      {/* Bar charts right */}
      <rect x="118" y="78" width="10" height="32" rx="2.5" fill="#B8D9F8" opacity="0.9" />
      <rect x="132" y="62" width="10" height="48" rx="2.5" fill="#ADD8E6" opacity="0.95" />

      {/* Arrow up */}
      <path
        d="M141 58 L152 47"
        stroke="#FFFFFF"
        strokeWidth="3.5"
        strokeLinecap="round"
      />
      <path
        d="M152 47 L152 57 M152 47 L142 47"
        stroke="#FFFFFF"
        strokeWidth="3.5"
        strokeLinecap="round"
        strokeLinejoin="round"
      />

      {/* Eye */}
      <ellipse cx="100" cy="114" rx="30" ry="21" fill="#B8D9F8" stroke="#ADD8E6" strokeWidth="1.5" />
      <circle cx="100" cy="114" r="12" fill="#0F2460" />
      <circle cx="95" cy="109" r="4.5" fill="#B8D9F8" opacity="0.9" />

      {/* Text */}
      <text
        x="100"
        y="160"
        fontFamily="Arial, sans-serif"
        fontSize="10"
        fontWeight="700"
        fill="#FFFFFF"
        textAnchor="middle"
        letterSpacing="2.5"
      >
        KARTIK
      </text>
      <text
        x="100"
        y="173"
        fontFamily="Arial, sans-serif"
        fontSize="10"
        fontWeight="400"
        fill="#B8D9F8"
        textAnchor="middle"
        letterSpacing="2.5"
      >
        CLARITY
      </text>
    </svg>
  );
}

interface WordmarkProps {
  className?: string;
  height?: number;
}

/**
 * Kartik Clarity wordmark – horizontal layout for header use.
 */
export function WordmarkLogo({ height = 36, className = "" }: WordmarkProps) {
  return (
    <svg
      height={height}
      viewBox="0 0 320 64"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
      role="img"
      aria-label="Kartik Clarity – Think. Focus. Achieve."
    >
      {/* Shield compact */}
      <path
        d="M20 6 L48 16 L48 42 C48 56 36 64 20 70 C4 64 -8 56 -8 42 L-8 16 Z"
        fill="#1B3A8C"
        stroke="#2A56D0"
        strokeWidth="1.5"
      />
      <path
        d="M20 14 L40 22 L40 42 C40 54 30 60 20 64 C10 60 0 54 0 42 L0 22 Z"
        fill="#1E40AF"
      />
      {/* Mini eye */}
      <ellipse cx="20" cy="42" rx="11" ry="8" fill="#B8D9F8" />
      <circle cx="20" cy="42" r="4.5" fill="#0F2460" />
      <circle cx="17.5" cy="39.5" r="1.8" fill="#B8D9F8" opacity="0.85" />
      {/* Mini bars */}
      <rect x="6" y="30" width="4" height="11" rx="1" fill="#FFFFFF" opacity="0.75" />
      <rect x="12" y="26" width="4" height="15" rx="1" fill="#FFFFFF" opacity="0.75" />
      <rect x="28" y="28" width="4" height="13" rx="1" fill="#FFFFFF" opacity="0.75" />
      <rect x="34" y="22" width="4" height="19" rx="1" fill="#FFFFFF" opacity="0.75" />
      <path d="M37 20 L42 15 M42 15 L42 21 M42 15 L36 15" stroke="#FFFFFF" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />

      {/* KARTIK */}
      <text
        x="58"
        y="28"
        fontFamily="Georgia, 'Times New Roman', serif"
        fontSize="22"
        fontWeight="700"
        fill="#1B3A8C"
        letterSpacing="-0.3"
      >
        KARTIK
      </text>
      {/* CLARITY */}
      <text
        x="58"
        y="50"
        fontFamily="Georgia, 'Times New Roman', serif"
        fontSize="22"
        fontWeight="400"
        fill="#2A56D0"
        letterSpacing="1.5"
      >
        CLARITY
      </text>
      {/* Tagline */}
      <text
        x="59"
        y="62"
        fontFamily="Arial, sans-serif"
        fontSize="7.5"
        fill="#B8D9F8"
        letterSpacing="2.5"
      >
        THINK · FOCUS · ACHIEVE
      </text>

      {/* Revenue Leak Detection badge */}
      <rect x="210" y="28" width="108" height="24" rx="3.5" fill="#B8D9F8" />
      <text
        x="264"
        y="44"
        fontFamily="Arial, sans-serif"
        fontSize="8"
        fontWeight="700"
        fill="#1B3A8C"
        textAnchor="middle"
        letterSpacing="0.4"
      >
        REVENUE LEAK DETECTION
      </text>
    </svg>
  );
}
