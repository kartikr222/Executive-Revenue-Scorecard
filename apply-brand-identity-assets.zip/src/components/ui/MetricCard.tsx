"use client";

import { type ReactNode } from "react";
import { clsx } from "clsx";

interface MetricCardProps {
  label: string;
  value: string;
  sub?: string;
  trend?: "up" | "down" | "neutral";
  trendLabel?: string;
  badge?: string;
  badgeVariant?: "critical" | "high" | "medium" | "low" | "positive" | "neutral";
  size?: "sm" | "md" | "lg";
  icon?: ReactNode;
  className?: string;
  onClick?: () => void;
}

export function MetricCard({
  label,
  value,
  sub,
  trend,
  trendLabel,
  badge,
  badgeVariant = "neutral",
  size = "md",
  icon,
  className,
  onClick,
}: MetricCardProps) {
  const badgeColors = {
    critical: "bg-red-100 text-red-700 border border-red-200",
    high: "bg-orange-100 text-orange-700 border border-orange-200",
    medium: "bg-yellow-100 text-yellow-700 border border-yellow-200",
    low: "bg-[#B8D9F8]/30 text-[#1B3A8C] border border-[#B8D9F8]",
    positive: "bg-emerald-100 text-emerald-700 border border-emerald-200",
    neutral: "bg-[#1B3A8C]/10 text-[#1B3A8C] border border-[#1B3A8C]/20",
  };

  const trendColors = {
    up: "text-emerald-600",
    down: "text-red-500",
    neutral: "text-[#2A56D0]",
  };

  const trendArrows = {
    up: "↑",
    down: "↓",
    neutral: "→",
  };

  return (
    <div
      className={clsx(
        "bg-white border border-[#1B3A8C]/12 rounded-xl p-5 transition-all duration-150",
        onClick && "cursor-pointer hover:border-[#2A56D0]/40 hover:shadow-sm",
        className
      )}
      onClick={onClick}
      role={onClick ? "button" : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={onClick ? (e) => e.key === "Enter" && onClick() : undefined}
    >
      <div className="flex items-start justify-between gap-2 mb-1">
        <span className="text-xs font-semibold uppercase tracking-[0.06em] text-[#1B3A8C]/60">
          {label}
        </span>
        {icon && <span className="text-[#2A56D0] opacity-70 mt-0.5">{icon}</span>}
        {badge && (
          <span className={clsx("text-[10px] font-semibold px-2 py-0.5 rounded-full", badgeColors[badgeVariant])}>
            {badge}
          </span>
        )}
      </div>

      <div
        className={clsx(
          "font-semibold text-[#0F2460] tabular-nums leading-none",
          size === "lg" && "text-3xl mt-2",
          size === "md" && "text-2xl mt-1.5",
          size === "sm" && "text-xl mt-1"
        )}
      >
        {value}
      </div>

      {(sub || trendLabel) && (
        <div className="mt-2 flex items-center gap-2 flex-wrap">
          {trendLabel && trend && (
            <span className={clsx("text-xs font-semibold", trendColors[trend])}>
              {trendArrows[trend]} {trendLabel}
            </span>
          )}
          {sub && (
            <span className="text-xs text-[#1B3A8C]/55">{sub}</span>
          )}
        </div>
      )}
    </div>
  );
}
