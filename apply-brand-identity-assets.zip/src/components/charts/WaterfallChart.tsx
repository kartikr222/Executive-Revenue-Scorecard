"use client";

import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Cell,
} from "recharts";
import { formatCurrency } from "@/lib/format";
import type { MrrWaterfall } from "@/lib/revenue-engine";

interface Props {
  waterfall: MrrWaterfall;
}

interface TooltipPayload {
  value: number;
  name: string;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload?.length) return null;
  const val = payload[0]?.value ?? 0;
  return (
    <div className="bg-[#0F2460] border border-[#2A56D0]/40 rounded-lg px-3 py-2 shadow-xl text-white">
      <div className="text-[10px] font-semibold text-[#B8D9F8] uppercase tracking-widest mb-1">{label}</div>
      <div className="text-sm font-bold">{formatCurrency(val, true)}</div>
    </div>
  );
}

export function WaterfallChart({ waterfall }: Props) {
  const data = [
    { name: "Opening", value: waterfall.opening, type: "opening" },
    { name: "New", value: waterfall.newMrr, type: "positive" },
    { name: "Expansion", value: waterfall.expansionMrr, type: "positive" },
    { name: "Churn", value: Math.abs(waterfall.churnedMrr), type: "negative" },
    { name: "Contraction", value: Math.abs(waterfall.contractionMrr), type: "negative" },
    { name: "Closing", value: waterfall.closing, type: "closing" },
  ];

  const colors: Record<string, string> = {
    opening: "#1B3A8C",
    positive: "#22c55e",
    negative: "#ef4444",
    closing: "#2A56D0",
  };

  return (
    <ResponsiveContainer width="100%" height={200}>
      <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="#1B3A8C" strokeOpacity={0.07} vertical={false} />
        <XAxis
          dataKey="name"
          tick={{ fontSize: 10, fill: "#1B3A8C", opacity: 0.6 }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          tick={{ fontSize: 10, fill: "#1B3A8C", opacity: 0.6 }}
          axisLine={false}
          tickLine={false}
          tickFormatter={(v: number) => formatCurrency(v, true)}
          width={44}
        />
        <Tooltip content={<CustomTooltip />} cursor={{ fill: "#1B3A8C", fillOpacity: 0.04 }} />
        <Bar dataKey="value" radius={[3, 3, 0, 0]}>
          {data.map((entry, index) => (
            <Cell key={index} fill={colors[entry.type]} />
          ))}
        </Bar>
      </BarChart>
    </ResponsiveContainer>
  );
}
