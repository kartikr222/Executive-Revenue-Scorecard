"use client";

import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";
import { formatPeriod } from "@/lib/format";
import type { CustomerCohort } from "@/lib/revenue-engine";

interface Props {
  cohorts: CustomerCohort[];
}

interface TooltipPayload {
  value: number;
  name: string;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload?.length) return null;
  const nrr = payload.find((p) => p.name === "NRR")?.value ?? 0;
  const grr = payload.find((p) => p.name === "GRR")?.value ?? 0;
  return (
    <div className="bg-[#0F2460] border border-[#2A56D0]/40 rounded-lg px-3 py-2 shadow-xl text-white min-w-[130px]">
      <div className="text-[10px] font-semibold text-[#B8D9F8] uppercase tracking-widest mb-1.5">{label}</div>
      <div className="space-y-1">
        <div className="flex justify-between gap-4">
          <span className="text-xs text-[#B8D9F8]">NRR</span>
          <span className={`text-xs font-bold ${nrr >= 100 ? "text-emerald-300" : "text-red-300"}`}>{nrr.toFixed(1)}%</span>
        </div>
        <div className="flex justify-between gap-4">
          <span className="text-xs text-[#B8D9F8]">GRR</span>
          <span className="text-xs font-semibold">{grr.toFixed(1)}%</span>
        </div>
      </div>
    </div>
  );
}

export function RetentionChart({ cohorts }: Props) {
  const data = cohorts.map((c) => {
    const nrr = (c.retainedMrr / c.initialMrr) * 100;
    const grr = (c.retainedCount / c.initialCount) * 100;
    return {
      period: formatPeriod(c.cohortPeriod),
      NRR: parseFloat(nrr.toFixed(1)),
      GRR: parseFloat(grr.toFixed(1)),
    };
  });

  return (
    <ResponsiveContainer width="100%" height={200}>
      <BarChart data={data} margin={{ top: 8, right: 8, bottom: 0, left: 0 }} barGap={2}>
        <CartesianGrid strokeDasharray="3 3" stroke="#1B3A8C" strokeOpacity={0.07} vertical={false} />
        <XAxis
          dataKey="period"
          tick={{ fontSize: 10, fill: "#1B3A8C", opacity: 0.55 }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          tick={{ fontSize: 10, fill: "#1B3A8C", opacity: 0.55 }}
          axisLine={false}
          tickLine={false}
          domain={[80, 115]}
          tickFormatter={(v: number) => `${v}%`}
          width={36}
        />
        <ReferenceLine y={100} stroke="#ef4444" strokeWidth={1} strokeDasharray="4 4" strokeOpacity={0.5} />
        <ReferenceLine y={110} stroke="#22c55e" strokeWidth={1} strokeDasharray="4 4" strokeOpacity={0.4} />
        <Tooltip content={<CustomTooltip />} cursor={{ fill: "#1B3A8C", fillOpacity: 0.04 }} />
        <Bar dataKey="NRR" fill="#2A56D0" radius={[3, 3, 0, 0]} maxBarSize={22} />
        <Bar dataKey="GRR" fill="#B8D9F8" radius={[3, 3, 0, 0]} maxBarSize={22} />
      </BarChart>
    </ResponsiveContainer>
  );
}
