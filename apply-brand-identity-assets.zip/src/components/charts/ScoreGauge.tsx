"use client";

import type { ExecutiveScore } from "@/lib/revenue-engine";

interface Props {
  score: ExecutiveScore;
}

export function ScoreGauge({ score }: Props) {
  const total = score.total;
  // SVG arc parameters
  const cx = 100;
  const cy = 110;
  const r = 82;
  const strokeWidth = 14;

  // Arc goes from -210° to 30° (240° sweep), starting from bottom-left
  const startAngle = -210; // degrees
  const sweepAngle = 240;

  function polarToCartesian(angle: number) {
    const rad = (angle * Math.PI) / 180;
    return {
      x: cx + r * Math.cos(rad),
      y: cy + r * Math.sin(rad),
    };
  }

  function describeArc(startDeg: number, endDeg: number) {
    const start = polarToCartesian(startDeg);
    const end = polarToCartesian(endDeg);
    const largeArc = endDeg - startDeg > 180 ? 1 : 0;
    return `M ${start.x} ${start.y} A ${r} ${r} 0 ${largeArc} 1 ${end.x} ${end.y}`;
  }

  const filledEnd = startAngle + (total / 100) * sweepAngle;
  const trackPath = describeArc(startAngle, startAngle + sweepAngle);
  const filledPath = describeArc(startAngle, filledEnd);

  const scoreColor =
    total >= 80 ? "#22c55e" : total >= 65 ? "#2A56D0" : total >= 50 ? "#f59e0b" : "#ef4444";

  const label =
    total >= 80 ? "STRONG" : total >= 65 ? "ADEQUATE" : total >= 50 ? "ATTENTION" : "CRITICAL";

  const dimensions = Object.entries(score.dimensions) as Array<
    [string, { score: number; weight: number; rationale: string }]
  >;

  const dimLabels: Record<string, string> = {
    revenuePerformance: "Revenue Performance",
    growthTrajectory: "Growth Trajectory",
    pipelineHealth: "Pipeline Health",
    retentionStrength: "Retention Strength",
    forecastConfidence: "Forecast Confidence",
  };

  return (
    <div className="flex flex-col items-center">
      {/* Gauge SVG */}
      <div className="relative" style={{ width: 200, height: 140 }}>
        <svg width={200} height={140} viewBox="0 0 200 140">
          {/* Track */}
          <path
            d={trackPath}
            fill="none"
            stroke="#1B3A8C"
            strokeOpacity={0.12}
            strokeWidth={strokeWidth}
            strokeLinecap="round"
          />
          {/* Filled arc */}
          {total > 0 && (
            <path
              d={filledPath}
              fill="none"
              stroke={scoreColor}
              strokeWidth={strokeWidth}
              strokeLinecap="round"
            />
          )}
          {/* Score number */}
          <text
            x={cx}
            y={cy + 4}
            textAnchor="middle"
            fontSize="36"
            fontWeight="700"
            fill="#0F2460"
            fontFamily="system-ui, sans-serif"
          >
            {Math.round(total)}
          </text>
          <text
            x={cx}
            y={cy + 22}
            textAnchor="middle"
            fontSize="10"
            fontWeight="700"
            fill={scoreColor}
            fontFamily="system-ui, sans-serif"
            letterSpacing="2"
          >
            {label}
          </text>
          <text
            x={cx}
            y={cy + 36}
            textAnchor="middle"
            fontSize="8.5"
            fill="#1B3A8C"
            fontFamily="system-ui, sans-serif"
            opacity={0.5}
          >
            / 100
          </text>
        </svg>
      </div>

      {/* Dimension breakdown */}
      <div className="w-full mt-1 space-y-2">
        {dimensions.map(([key, dim]) => (
          <div key={key}>
            <div className="flex justify-between items-center mb-0.5">
              <span className="text-[10px] text-[#1B3A8C]/65 font-medium">{dimLabels[key]}</span>
              <span className="text-[10px] font-bold text-[#0F2460]">
                {Math.round(dim.score)}<span className="text-[#1B3A8C]/40">/{dim.weight}</span>
              </span>
            </div>
            <div className="h-1.5 bg-[#1B3A8C]/10 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(100, (dim.score / 100) * 100)}%`,
                  backgroundColor: dim.score >= 70 ? "#22c55e" : dim.score >= 50 ? "#2A56D0" : "#ef4444",
                }}
              />
            </div>
          </div>
        ))}
      </div>

      {/* Confidence indicator */}
      <div className="mt-3 text-center">
        <span className="text-[10px] text-[#1B3A8C]/50 uppercase tracking-widest">
          Score confidence: <span className="font-bold text-[#1B3A8C]">{score.confidence.toUpperCase()}</span>
        </span>
      </div>
    </div>
  );
}
