"use client";

import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
  Line,
  ComposedChart,
} from "recharts";
import { formatCurrency, formatPeriod } from "@/lib/format";
import type { MrrWaterfall } from "@/lib/revenue-engine";

interface Props {
  waterfalls: MrrWaterfall[];
}

interface TooltipPayload {
  value: number;
  name: string;
  color: string;
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: TooltipPayload[];
  label?: string;
}

function CustomTooltip({ active, payload, label }: CustomTooltipProps) {
  if (!active || !payload?.length) return null;
  const closing = payload.find((p) => p.name === "MRR")?.value ?? 0;
  const plan = payload.find((p) => p.name === "Plan")?.value ?? 0;
  const vsplan = closing - plan;

  return (
    <div className="bg-[#0F2460] border border-[#2A56D0]/40 rounded-lg px-4 py-3 shadow-xl text-white min-w-[160px]">
      <div className="text-[10px] font-semibold text-[#B8D9F8] uppercase tracking-widest mb-2">
        {label}
      </div>
      <div className="space-y-1">
        <div className="flex justify-between gap-6">
          <span className="text-xs text-[#B8D9F8]">MRR</span>
          <span className="text-xs font-semibold">{formatCurrency(closing, true)}</span>
        </div>
        <div className="flex justify-between gap-6">
          <span className="text-xs text-[#B8D9F8]">Plan</span>
          <span className="text-xs font-semibold">{formatCurrency(plan, true)}</span>
        </div>
        <div className="border-t border-white/10 pt-1 mt-1 flex justify-between gap-6">
          <span className="text-xs text-[#B8D9F8]">vs Plan</span>
          <span className={`text-xs font-bold ${vsplan >= 0 ? "text-emerald-300" : "text-red-300"}`}>
            {vsplan >= 0 ? "+" : ""}{formatCurrency(vsplan, true)}
          </span>
        </div>
      </div>
    </div>
  );
}

export function MrrTrendChart({ waterfalls }: Props) {
  const data = waterfalls.map((w) => ({
    period: formatPeriod(w.period),
    MRR: w.closing,
    Plan: w.plan,
  }));

  const maxVal = Math.max(...data.map((d) => Math.max(d.MRR, d.Plan)));

  return (
    <ResponsiveContainer width="100%" height={260}>
      <ComposedChart data={data} margin={{ top: 8, right: 16, bottom: 0, left: 0 }}>
        <defs>
          <linearGradient id="mrrGradient" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#2A56D0" stopOpacity={0.18} />
            <stop offset="100%" stopColor="#2A56D0" stopOpacity={0.01} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke="#1B3A8C" strokeOpacity={0.08} vertical={false} />
        <XAxis
          dataKey="period"
          tick={{ fontSize: 11, fill: "#1B3A8C", opacity: 0.55, fontWeight: 500 }}
          axisLine={false}
          tickLine={false}
        />
        <YAxis
          tick={{ fontSize: 11, fill: "#1B3A8C", opacity: 0.55 }}
          axisLine={false}
          tickLine={false}
          tickFormatter={(v: number) => formatCurrency(v, true)}
          domain={[0, maxVal * 1.08]}
          width={52}
        />
        <Tooltip content={<CustomTooltip />} cursor={{ stroke: "#2A56D0", strokeWidth: 1, strokeOpacity: 0.3 }} />
        <Area
          type="monotone"
          dataKey="MRR"
          stroke="#2A56D0"
          strokeWidth={2.5}
          fill="url(#mrrGradient)"
          dot={false}
          activeDot={{ r: 4, fill: "#2A56D0", strokeWidth: 2, stroke: "#fff" }}
        />
        <Line
          type="monotone"
          dataKey="Plan"
          stroke="#B8D9F8"
          strokeWidth={1.5}
          strokeDasharray="5 4"
          dot={false}
          activeDot={{ r: 3, fill: "#B8D9F8", strokeWidth: 0 }}
        />
      </ComposedChart>
    </ResponsiveContainer>
  );
}
