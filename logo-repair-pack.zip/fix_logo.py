#!/usr/bin/env python3
"""Kartik Clarity logo repair. Run from the ROOT of the cloned repo:

    python3 fix_logo.py          # audit only (writes LOGO_MAP.md, changes nothing)
    python3 fix_logo.py --apply  # copy assets, normalise refs, favicons, cache-bust, verify

Idempotent. Needs only Python 3.
"""
import hashlib, os, re, shutil, sys, xml.dom.minidom
from pathlib import Path

APPLY = "--apply" in sys.argv
PACK = Path(__file__).resolve().parent
ROOT = Path.cwd()
CANON = ["logo-circle.svg", "logo-rectangle.svg"]
ICONS = ["favicon.ico", "favicon-32.png", "apple-touch-icon.png", "icon-192.png"]
TEXT_EXT = {".html", ".htm", ".css", ".js", ".mjs", ".json", ".webmanifest", ".txt"}
SKIP_DIRS = {".git", "node_modules", "dist", "build"}

def files():
    for p in ROOT.rglob("*"):
        if p.is_file() and p.suffix.lower() in TEXT_EXT and not (set(p.relative_to(ROOT).parts) & SKIP_DIRS):
            yield p

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()[:10]

# ---- 1. install canonical assets ------------------------------------------------
if APPLY:
    (ROOT / "assets").mkdir(exist_ok=True)
    for n in CANON + ICONS:
        shutil.copy2(PACK / "assets" / n, ROOT / "assets" / n)
    print("copied", len(CANON + ICONS), "assets -> assets/")
VER = {n: sha(ROOT / "assets" / n) if (ROOT / "assets" / n).exists() else sha(PACK / "assets" / n) for n in CANON + ICONS}

# ---- 2. audit: FILE -> REFERENCE -> LINE ----------------------------------------
ref_re = re.compile(r"""(?i)(logo|favicon|apple-touch|kartik clarity|\.(svg|png|jpe?g|webp)\b|assets/)""")
risky_css = re.compile(r"(?i)(display\s*:\s*none|visibility\s*:\s*hidden|opacity\s*:\s*0(?![.\d])|clip-path|mask|filter\s*:|overflow\s*:\s*hidden|width\s*:\s*0|height\s*:\s*0|object-fit)")
rows, flags = [], []
for p in files():
    rel = p.relative_to(ROOT).as_posix()
    for i, line in enumerate(p.read_text(encoding="utf8", errors="ignore").splitlines(), 1):
        if ref_re.search(line) and len(line) < 400:
            rows.append((rel, i, line.strip()))
        if p.suffix == ".css" and re.search(r"(?i)logo|brand", line) and risky_css.search(line):
            flags.append((rel, i, line.strip(), "CSS rule on a logo/brand selector can hide or clip it"))
        if p.suffix == ".js" and re.search(r"(?i)logo|brand", line) and re.search(r"(\.remove\(|innerHTML|outerHTML|\.src\s*=|setAttribute\(.src|style\.display|replaceWith)", line):
            flags.append((rel, i, line.strip(), "JS rewrites/removes logo or brand markup at runtime"))

with open("LOGO_MAP.md", "w", encoding="utf8") as f:
    f.write("# FILE -> LOGO REFERENCE map\n\n| file | line | reference |\n|---|---|---|\n")
    for r in rows:
        f.write("| %s | %d | `%s` |\n" % (r[0], r[1], r[2].replace("|", "\\|")[:200]))
    f.write("\n# Runtime/CSS suspects (review each)\n\n")
    for r in flags:
        f.write("- **%s:%d** %s -> `%s`\n" % (r[0], r[1], r[3], r[2][:200]))
print("audit: %d references, %d suspects -> LOGO_MAP.md" % (len(rows), len(flags)))
for r in flags:
    print("  SUSPECT %s:%d  %s" % (r[0], r[1], r[3]))

if not APPLY:
    sys.exit(0)

# ---- 3. normalise every reference to the two canonical logos --------------------
# any of: absolute github.io URL, /Executive-Revenue-Scorecard/assets/..., /assets/..., ./assets/..., assets/...
# and any old extension  ->  assets/logo-X.svg?v=<hash>   (relative, so it is base-path safe)
pat = re.compile(r"""(?:https?://[\w.-]+/Executive-Revenue-Scorecard/|/Executive-Revenue-Scorecard/|\.?/)?assets/logo-(circle|rectangle)\.(?:svg|png|jpe?g|webp)(?:\?[\w=.&-]*)?""", re.I)
changed = []
for p in files():
    if p.name == "fix_logo.py":
        continue
    s = p.read_text(encoding="utf8")
    n = pat.sub(lambda m: "assets/logo-%s.svg?v=%s" % (m.group(1).lower(), VER["logo-%s.svg" % m.group(1).lower()]), s)
    if n != s:
        p.write_text(n, encoding="utf8"); changed.append(p.relative_to(ROOT).as_posix())
print("normalised logo refs in:", changed or "nothing needed")

# ---- 4. favicon + touch icon (PNG/ICO, never a 180 KB SVG) ----------------------
fav = ('<link rel="icon" href="assets/favicon.ico?v={ico}" sizes="any">\n'
       '<link rel="icon" type="image/png" sizes="32x32" href="assets/favicon-32.png?v={f32}">\n'
       '<link rel="apple-touch-icon" sizes="180x180" href="assets/apple-touch-icon.png?v={apple}">\n').format(
       ico=VER["favicon.ico"], f32=VER["favicon-32.png"], apple=VER["apple-touch-icon.png"])
for name in ("index.html", "404.html"):
    p = ROOT / name
    if not p.exists():
        continue
    s = p.read_text(encoding="utf8")
    s = re.sub(r'\s*<link[^>]+rel=["\'](?:shortcut )?icon["\'][^>]*>', "", s, flags=re.I)
    s = re.sub(r'\s*<link[^>]+rel=["\']apple-touch-icon[^>]*>', "", s, flags=re.I)
    s = re.sub(r"(?i)<head([^>]*)>", lambda m: "<head%s>\n%s" % (m.group(1), fav), s, count=1)
    p.write_text(s, encoding="utf8")
    print("favicon links set in", name)

# ---- 5. verify -------------------------------------------------------------------
bad = 0
for n in CANON:
    t = (ROOT / "assets" / n).read_text(encoding="utf8")
    try:
        xml.dom.minidom.parseString(t)
    except Exception as e:
        print("FAIL invalid XML", n, e); bad += 1
    if re.search(r'href="(?!data:|#)', t):
        print("FAIL external href inside", n); bad += 1
url = re.compile(r"""(?:src|href)=["']([^"'#]+)|url\(["']?([^"')]+)""")
for p in files():
    if p.suffix.lower() not in (".html", ".css"):
        continue
    for m in url.finditer(p.read_text(encoding="utf8", errors="ignore")):
        u = (m.group(1) or m.group(2) or "").split("?")[0]
        if not re.search(r"assets/", u) or u.startswith("http") and "github.io" not in u:
            continue
        rel = re.sub(r"^https?://[^/]+/Executive-Revenue-Scorecard/", "", u).lstrip("./").lstrip("/")
        if not (ROOT / rel).exists():
            print("FAIL missing asset: %s referenced from %s" % (u, p.name)); bad += 1
print("VERIFY:", "ALL OK" if not bad else "%d PROBLEM(S)" % bad)
sys.exit(1 if bad else 0)
